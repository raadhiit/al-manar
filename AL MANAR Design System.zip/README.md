# AL MANAR — Design System

Brand & component system for **Yayasan AL MANAR Kota Bekasi**, an Islamic school
foundation (yayasan) in Bekasi, West Java, Indonesia. It covers two education units
under one brand:

- **SDIT AL MANAR** — Sekolah Dasar Islam Terpadu (Islamic primary, ages 7–12)
- **TKIT AL MANAR** — TK Islam Terpadu (Islamic kindergarten, ages 4–6)

> **AL MANAR** (المنار) is Arabic for *"the lighthouse / the beacon."* The brand
> idea — **light, guidance, knowledge** — drives every choice: a deep, steady green
> (trust, growth, Islamic identity) lit by warm gold (cahaya / the beam of light),
> set on calm cream paper. The audience is **parents of children aged 4–12** choosing
> a school, so the system reads **professional, trustworthy, and warm** — never
> clip-arty, neon, or childish.

This system is intentionally **minimalist but not empty**: generous whitespace and a
restrained palette, but every section carries real information (stats, schedules,
achievements, news) and tasteful interaction. Subtle Islamic geometry (an 8-point
*girih* star, derived from the Rub el Hizb ۞) appears as a low-opacity texture behind
brand bands — an accent, never decoration for its own sake.

---

## Sources

- **Codebase:** [`raadhiit/al-manar`](https://github.com/raadhiit/al-manar) — at the time
  of authoring this is a **fresh Laravel 13 scaffold** (default welcome page, Tailwind v4,
  no custom design yet). There was no prior visual language to reverse-engineer, so this
  system was designed from the brief. Explore the repo for the production app structure.
- **Target stack (developer handoff):** Laravel 13 + PHP 8.4 · Blade + Livewire v4 +
  Alpine.js + **Tailwind CSS v4** · Filament v5.6 admin · Spatie Permission + Filament
  Shield · MySQL 8 · Laravel Storage (`private/registrations/`) · SMTP mail ·
  Domainesia Nimbus Go (LiteSpeed). Tokens here map cleanly to Tailwind v4 `@theme` vars.

---

## Content fundamentals

The product language is **Bahasa Indonesia**, warm and respectful, with light Islamic
register. Tone is that of a trusted, established school speaking *to parents*.

- **Language:** Indonesian for all UI and copy. Arabic appears only as short devotional
  or brand accents (`السلام عليكم`, `المنار`) set in Amiri — never as body text.
- **Voice:** warm, calm, confident. We address the visitor as a respected parent
  ("Bapak/Ibu"), the school as "kami." Avoid hard-sell; lead with care and credibility.
- **Casing:** Sentence case for body and most headings. ALL-CAPS only for tiny eyebrow
  labels (`UNIT PENDIDIKAN`, `PPDB 2026`) with wide tracking. Acronyms stay caps:
  SDIT, TKIT, PPDB, BAN-S/M.
- **Numbers (Indonesian convention):** thousands use a dot — `1.200 alumni`, `Rp 350.000`.
  Dates spelled out: `12 Mei 2026`.
- **CTAs are short imperatives:** *Daftar Sekarang*, *Selengkapnya*, *Lihat Semua*,
  *Unduh Brosur*, *Hubungi Kami*.
- **No emoji.** Warmth comes from tone, photography, and the gold accent — not emoji.
- **Recurring phrases / motto candidates:** *"Cahaya Ilmu, Akhlak Mulia"* (Light of
  Knowledge, Noble Character); *"Membentuk Generasi Qur'ani"*; *"Terpadu, Berprestasi,
  Berakhlak."*
- **Vibe example (hero):** eyebrow `YAYASAN AL MANAR · KOTA BEKASI` → headline
  *"Menumbuhkan generasi Qur'ani yang berakhlak & berprestasi"* → lead sentence about
  integrated Islamic education from TK to SD → buttons *Daftar Sekarang* / *Profil Sekolah*.

---

## Visual foundations

**Color.** Deep pine **green** (`--green-600 #155742`) is the primary — used for the
masthead brand, primary buttons, dark CTA bands, and the footer. Antique **gold**
(`--gold-400 #D9AB3D`) is the single accent: eyebrow ticks, the TKIT level, secondary
buttons, hairline highlights, and the geometric pattern stroke. Pages sit on warm
**cream** (`--cream-50 #FBF8F1`), never stark white; cards are white on cream for a
soft, paper-like calm. Text is a green-tinted near-black (`--ink-900 #15201B`), never
pure `#000`. **No gradients as fills, no purple, no neon, no dark theme.** The only
"gradient" permitted is an occasional protective scrim over a photo for legible captions.

**Type.** Display/headings in **Lora** (a calligraphic-rooted serif → trust, scholarship,
warmth); body & UI in **Plus Jakarta Sans** (designed in Jakarta — locally grounded,
clean, highly legible); Arabic accents in **Amiri** (classic Naskh). Scale is a ~1.2
minor-third; the two largest display steps go fluid via `clamp()`. Headings are bold
with tight tracking and balanced wrapping; body is `line-height: 1.55` with
`text-wrap: pretty`.

**Spacing & layout.** 4px base grid. Content max-width `1200px` with `1.5rem` gutters.
Vertical section rhythm is fluid (`--section-y`, ~56–96px). Layouts favour flex/grid
with `gap` over inline flow. Generous negative space is part of the brand — pages
breathe.

**Backgrounds.** Three treatments: (1) plain cream/white for most content; (2) a deep
**green brand band** (`--green-700/800`) for hero edges, CTA strips, and the footer,
often carrying the girih texture at ~10% opacity; (3) a **cream-100** sunken band to
separate sections. No photographic full-bleed backgrounds behind text without a scrim.
Imagery is warm and natural (school life, smiling children, classrooms) — where real
photos are absent, a styled `MediaPlaceholder` (girih + icon) holds the space.

**Corners & cards.** Friendly but professional radii: cards `--radius-lg 16px`, larger
feature cards `--radius-xl 24px`, inputs `--radius-md 12px`, **buttons are full pills**
(`--radius-pill`). Cards = white surface + 1px warm border (`--border-default`) + an
extra-soft shadow (`--shadow-xs`), lifting to `--shadow-md` and `translateY(-3px)` on
hover.

**Shadows & borders.** Restrained and **warm green-tinted** (`rgba(16,40,28,…)`), low
spread. The system leans on **hairline borders** more than heavy shadows — a quiet,
trustworthy institutional feel. A 1px gold tick or 2px gold underline is the signature
accent detail.

**Motion.** Calm and quick. Transitions `140–360ms` on `--ease-soft` /`--ease-out`.
Hovers: links grow a gold underline (scaleX from left), cards lift gently, buttons
darken one step. Press: buttons `translateY(1px)`. No bounce, no parallax, no infinite
loops. Entrance animations (if any) fade/rise from the visible end-state and respect
`prefers-reduced-motion`.

**Transparency & blur.** Used sparingly: the sticky navbar uses
`rgba(cream, .92)` + `backdrop-filter: blur(8px)`; photo captions use a bottom scrim.
Otherwise surfaces are solid.

---

## Iconography

- **System:** [**Lucide**](https://lucide.dev) — clean 2px-stroke line icons. Their
  even weight and rounded caps match the calm, modern-institutional tone. Load from CDN
  (`https://unpkg.com/lucide@latest`) or inline the SVG paths (several components inline a
  handful: calendar, arrow, upload, check, image). **Substitution note:** Lucide is a
  chosen default (no icon set existed in the repo) — swap to your production set freely;
  keep the 2px line style.
- **Brand emblem:** the **Rub el Hizb** 8-point star (two overlapping squares) with a
  central mihrab-arch / light motif — see `assets/logo-mark.svg` (dark) and
  `assets/logo-mark-light.svg` (for green backgrounds). This is the only bespoke mark;
  do not redraw it ad hoc — use the `Logo` component.
- **Pattern:** the same girih star tiles as `--pattern-girih` (and inside `PatternBand`
  / `MediaPlaceholder`) — a single-color, low-opacity texture, never a foreground graphic.
- **Emoji / unicode:** **not used.** Level distinctions use the `Badge` component
  (SDIT = green, TKIT = gold), not emoji or flags.

---

## Index / manifest

**Root**
- `styles.css` — global entry point (consumers link this); `@import`s everything below.
- `tokens/` — `fonts.css` (Google Fonts: Lora · Plus Jakarta Sans · Amiri),
  `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `base.css`.
- `assets/` — `logo-mark.svg`, `logo-mark-light.svg`.
- `SKILL.md` — Agent-Skill manifest (downloadable / Claude Code compatible).

**Components** (`components/<group>/` — each has `.jsx` + `.d.ts` + a `@dsCard` HTML)
- `brand/` — **Logo**, **PatternBand**
- `core/` — **Button**, **Badge**, **Stat**
- `forms/` — **Input**, **Select**, **Textarea**, **FormField**, **FileUpload**
- `navigation/` — **NavBar**, **Footer**
- `content/` — **SectionHeader**, **Card** (+ **MediaPlaceholder**), **SchoolCard**, **NewsCard**

**Foundations** (`guidelines/` — specimen cards shown in the Design System tab)
- Colour, type, spacing, radii/shadow, and brand specimen cards.

**UI kit** (`ui_kits/website/`)
- Full AL MANAR website recreation: Homepage, School Profile (SDIT/TKIT), News, Gallery,
  Registration (PPDB) form, and Academic Portal — desktop + mobile responsive.
  `index.html` is the interactive click-through.

> **Fonts note:** Lora, Plus Jakarta Sans, and Amiri load from the **Google Fonts CDN**
> (see `tokens/fonts.css`), not self-hosted. For an offline/production build, download the
> `.woff2` files and replace the `@import` with local `@font-face` rules. Flag raised for
> the user — happy to self-host if you upload or approve the font binaries.
