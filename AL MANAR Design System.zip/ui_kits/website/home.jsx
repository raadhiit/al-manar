/* AL MANAR — Homepage */
function Home({ go }) {
  return (
    <>
      <HomeHero go={go} />
      <SchoolsSplit go={go} />
      <AchievementsBand />
      <NewsPreview go={go} />
      <ActivitiesStrip />
      <GalleryTeaser go={go} />
      <PpdbCta go={go} />
    </>
  );
}

/* ── Hero ──────────────────────────────────────────────────────── */
function HomeHero({ go }) {
  return (
    <section style={{ background:'var(--cream-50)', position:'relative', overflow:'hidden' }}>
      <Container style={{ display:'grid', gridTemplateColumns:'1.05fr 0.95fr', gap:56, alignItems:'center', paddingTop:'clamp(2.5rem,4vw,4.5rem)', paddingBottom:'clamp(2.5rem,4vw,4.5rem)' }} wide>
        <div style={{ display:'flex', flexDirection:'column', gap:24, maxWidth:560 }}>
          <span style={{ display:'inline-flex', alignItems:'center', gap:10, fontFamily:'var(--font-sans)', fontSize:13, fontWeight:700, letterSpacing:'.14em', textTransform:'uppercase', color:'var(--gold-600)' }}>
            <span style={{ width:22, height:2, background:'var(--gold-400)', borderRadius:2 }} />
            Yayasan AL MANAR · Kota Bekasi
          </span>
          <h1 style={{ fontFamily:'var(--font-display)', fontWeight:700, fontSize:'var(--text-5xl)', lineHeight:1.06, letterSpacing:'-0.025em', color:'var(--ink-900)', margin:0 }}>
            Menumbuhkan generasi <span style={{ color:'var(--green-600)' }}>Qur'ani</span> yang berakhlak &amp; berprestasi
          </h1>
          <p style={{ fontFamily:'var(--font-sans)', fontSize:'var(--text-md)', lineHeight:1.7, color:'var(--ink-500)', margin:0 }}>
            Pendidikan Islam terpadu dari TK hingga sekolah dasar — memadukan kurikulum nasional, pembinaan akhlak, dan tahfizh Al-Qur'an di lingkungan yang hangat dan aman.
          </p>
          <div style={{ display:'flex', gap:14, flexWrap:'wrap', marginTop:4 }}>
            <Button variant="primary" size="lg" onClick={() => go('registration')}>Daftar Sekarang</Button>
            <Button variant="outline" size="lg" onClick={() => go('sdit')}>Profil Sekolah</Button>
          </div>
          <div style={{ display:'flex', gap:36, marginTop:14, paddingTop:22, borderTop:'1px solid var(--border-subtle)' }}>
            <Stat value="A" label="Akreditasi" sublabel="SDIT & TKIT" tone="gold" />
            <Stat value="1.200+" label="Alumni" sublabel="Sejak 2009" />
            <Stat value="40+" label="Tenaga Pendidik" sublabel="Tersertifikasi" />
          </div>
        </div>

        <div style={{ position:'relative' }}>
          <div style={{ borderRadius:'var(--radius-2xl)', overflow:'hidden', border:'1px solid var(--border-default)', boxShadow:'var(--shadow-lg)' }}>
            <MediaPlaceholder height={420} label="Foto suasana sekolah" tone="green" />
          </div>
          <div style={{ position:'absolute', left:-18, bottom:28, background:'#fff', borderRadius:'var(--radius-lg)', boxShadow:'var(--shadow-md)', border:'1px solid var(--border-default)', padding:'14px 18px', display:'flex', alignItems:'center', gap:13 }}>
            <Logo variant="mark" size={42} />
            <div style={{ display:'flex', flexDirection:'column' }}>
              <span style={{ fontFamily:'var(--font-arabic)', direction:'rtl', fontSize:22, color:'var(--green-700)', lineHeight:1 }}>المنار</span>
              <span style={{ fontFamily:'var(--font-sans)', fontSize:12, color:'var(--ink-500)', marginTop:3 }}>Cahaya Ilmu, Akhlak Mulia</span>
            </div>
          </div>
          <div style={{ position:'absolute', right:-14, top:24 }}>
            <Badge tone="success" variant="solid" size="md">PPDB 2026 Dibuka</Badge>
          </div>
        </div>
      </Container>
    </section>
  );
}

/* ── Schools split ─────────────────────────────────────────────── */
function SchoolsSplit({ go }) {
  return (
    <Section bg="page">
      <Container>
        <Reveal><SectionHeader eyebrow="Unit Pendidikan" title="Satu yayasan, dua jenjang terpadu" lead="Pendidikan Islam yang berkesinambungan — dari usia dini hingga sekolah dasar." style={{ marginBottom:36 }} /></Reveal>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:28 }} className="am-grid-2">
          <Reveal>
            <SchoolCard level="SDIT" name="SDIT AL MANAR" tagline="Sekolah Dasar Islam Terpadu"
              description="Kurikulum nasional terintegrasi nilai Islam, program tahfizh, dan pembinaan karakter yang kuat."
              ageRange="7–12 tahun" accreditation="A"
              points={["Target hafalan hingga 3 juz","Pembelajaran bilingual & literasi digital","Ekstrakurikuler lengkap & pramuka SIT"]}
              media={<MediaPlaceholder height={190} label="Foto SDIT" tone="green" />}
              onClick={() => go('sdit')} style={{ cursor:'pointer' }} />
          </Reveal>
          <Reveal delay={80}>
            <SchoolCard level="TKIT" name="TKIT AL MANAR" tagline="TK Islam Terpadu"
              description="Belajar sambil bermain dengan pembiasaan ibadah, adab, dan stimulasi tumbuh kembang yang menyenangkan."
              ageRange="4–6 tahun" accreditation="A"
              points={["Sentra bermain edukatif","Pembiasaan sholat, doa & hadits","Rasio guru–murid ideal"]}
              media={<MediaPlaceholder height={190} label="Foto TKIT" tone="gold" />}
              onClick={() => go('tkit')} style={{ cursor:'pointer' }} />
          </Reveal>
        </div>
      </Container>
    </Section>
  );
}

/* ── Achievements band (green) ─────────────────────────────────── */
function AchievementsBand() {
  const stats = [
    { value:'32', label:'Prestasi diraih', sub:'2 tahun terakhir' },
    { value:'95%', label:'Lulusan diterima', sub:'SMP/MTs favorit' },
    { value:'3 Juz', label:'Target tahfizh', sub:'Jenjang SDIT' },
    { value:'18', label:'Ekstrakurikuler', sub:'Akademik & non-akademik' },
  ];
  return (
    <section style={{ background:'var(--green-800)', position:'relative', overflow:'hidden' }}>
      <div style={{ position:'absolute', inset:0, backgroundImage:'var(--pattern-girih)', opacity:.5 }} aria-hidden="true" />
      <Container style={{ position:'relative', paddingTop:'var(--section-y)', paddingBottom:'var(--section-y)' }}>
        <Reveal><SectionHeader tone="onbrand" align="center" eyebrow="Prestasi & Capaian" title="Hasil yang membanggakan, akhlak yang utama" style={{ justifyContent:'center', marginBottom:40 }} /></Reveal>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:24 }} className="am-grid-4">
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={i*70}>
              <div style={{ background:'rgba(251,248,241,0.06)', border:'1px solid rgba(217,171,61,0.25)', borderRadius:'var(--radius-lg)', padding:'24px 22px' }}>
                <Stat value={s.value} label={s.label} sublabel={s.sub} tone="onbrand" />
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}

Object.assign(window, { Home });
