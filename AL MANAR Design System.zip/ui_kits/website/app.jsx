/* AL MANAR website — app shell + shared layout helpers.
 * DS components are available as globals (flattened from the bundle in index.html).
 */
const { useState } = React;

/* ── Layout primitives ─────────────────────────────────────────── */
function Container({ children, wide, style }) {
  return <div style={{ width:'100%', maxWidth: wide ? 'var(--container-wide)' : 'var(--container-max)', margin:'0 auto', padding:'0 var(--gutter)', ...style }}>{children}</div>;
}

function Section({ children, bg = 'page', pad = 'var(--section-y)', style }) {
  const background = bg === 'cream' ? 'var(--cream-100)' : bg === 'green' ? 'var(--green-800)' : bg === 'white' ? '#fff' : 'var(--cream-50)';
  return <section style={{ background, paddingTop: pad, paddingBottom: pad, ...style }}>{children}</section>;
}

/* Simple intersection-reveal wrapper (fade + rise, respects reduced motion) */
function Reveal({ children, delay = 0, style }) {
  const ref = React.useRef(null);
  const [vis, setVis] = useState(false);
  React.useEffect(() => {
    const el = ref.current; if (!el) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { setVis(true); return; }
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { setVis(true); io.disconnect(); } }), { threshold: 0.12 });
    io.observe(el); return () => io.disconnect();
  }, []);
  return <div ref={ref} style={{ opacity: vis ? 1 : 0, transform: vis ? 'none' : 'translateY(16px)', transition: `opacity .6s var(--ease-out) ${delay}ms, transform .6s var(--ease-out) ${delay}ms`, ...style }}>{children}</div>;
}

Object.assign(window, { Container, Section, Reveal });

/* ── App root ──────────────────────────────────────────────────── */
const NAV_ITEMS = [
  { key:'home', label:'Beranda', href:'#' },
  { key:'news', label:'Berita', href:'#' },
  { key:'achievements', label:'Prestasi', href:'#' },
  { key:'gallery', label:'Galeri', href:'#' },
  { key:'sekolah', label:'Sekolah', href:'#', children:[
    { key:'sdit', label:'SDIT AL MANAR', desc:'Sekolah Dasar Islam Terpadu', href:'#' },
    { key:'tkit', label:'TKIT AL MANAR', desc:'TK Islam Terpadu', href:'#' },
  ]},
  { key:'portal', label:'Portal Akademik', href:'#' },
  { key:'kontak', label:'Kontak', href:'#' },
];

function App() {
  const [page, setPage] = useState('home');
  const [school, setSchool] = useState('SDIT');

  const go = (key, opts = {}) => {
    if (key === 'sdit') { setSchool('SDIT'); setPage('profile'); }
    else if (key === 'tkit') { setSchool('TKIT'); setPage('profile'); }
    else if (key === 'achievements') setPage('news');
    else if (key === 'kontak') setPage('home');
    else setPage(key);
    if (opts.school) setSchool(opts.school);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const items = NAV_ITEMS.map((it) => ({ ...it, active: it.key === page || (it.key === 'sekolah' && page === 'profile') }));

  const Page =
    page === 'profile' ? <SchoolProfile school={school} go={go} setSchool={setSchool} /> :
    page === 'news' ? <NewsPage go={go} /> :
    page === 'gallery' ? <GalleryPage go={go} /> :
    page === 'registration' ? <Registration go={go} defaultSchool={school} /> :
    page === 'portal' ? <AcademicPortal go={go} /> :
    <Home go={go} />;

  return (
    <div style={{ minHeight:'100vh', display:'flex', flexDirection:'column', background:'var(--cream-50)' }}>
      <NavBar items={items} ctaLabel="Daftar Sekarang" onCta={() => go('registration')} onNavigate={(it) => go(it.key)} />
      <main style={{ flex:1 }}>{Page}</main>
      <Footer />
    </div>
  );
}

Object.assign(window, { App });
