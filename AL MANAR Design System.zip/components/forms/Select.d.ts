import * as React from 'react';
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  invalid?: boolean;
  children?: React.ReactNode;
}
export function Select(props: SelectProps): JSX.Element;
