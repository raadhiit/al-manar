import React from 'react';

/** Multi-line text input, styled to match Input. */
export function Textarea({ invalid=false, className='', style, ...rest }) {
  return <textarea className={`am-field-textarea ${className}`} data-invalid={invalid} style={style} {...rest} />;
}
