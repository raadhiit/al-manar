import React from 'react';

/** Native select, styled to match Input. Pass <option> children. */
export function Select({ invalid=false, className='', children, style, ...rest }) {
  if (typeof document!=='undefined' && !document.getElementById('am-field-css')){
    // FIELD_CSS is injected by Input; ensure presence if Select used alone
    const s=document.createElement('style');s.id='am-field-css';
    s.textContent=`.am-field-select{width:100%;font-family:var(--font-sans);font-size:var(--text-base);color:var(--ink-900);background:#fff;border:1.5px solid var(--border-default);border-radius:var(--radius-md);padding:.7em 2.2em .7em .9em;line-height:1.4;appearance:none;-webkit-appearance:none;}.am-field-select:focus{outline:none;border-color:var(--green-600);box-shadow:var(--ring-focus);}.am-select-wrap{position:relative;}.am-select-wrap::after{content:"";position:absolute;right:14px;top:50%;width:9px;height:9px;border-right:2px solid var(--ink-500);border-bottom:2px solid var(--ink-500);transform:translateY(-65%) rotate(45deg);pointer-events:none;}`;
    document.head.appendChild(s);
  }
  return (
    <span className="am-select-wrap" style={{display:'block',...style}}>
      <select className={`am-field-select ${className}`} data-invalid={invalid} {...rest}>{children}</select>
    </span>
  );
}
