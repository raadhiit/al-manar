import React from 'react';

const FIELD_CSS = `
.am-field-input,.am-field-select,.am-field-textarea{
  width:100%;font-family:var(--font-sans);font-size:var(--text-base);color:var(--ink-900);
  background:#fff;border:1.5px solid var(--border-default);border-radius:var(--radius-md);
  padding:.7em .9em;line-height:1.4;transition:border-color var(--dur-fast),box-shadow var(--dur-fast);
  appearance:none;-webkit-appearance:none;}
.am-field-textarea{min-height:120px;resize:vertical;}
.am-field-input::placeholder,.am-field-textarea::placeholder{color:var(--ink-400);}
.am-field-input:focus,.am-field-select:focus,.am-field-textarea:focus{
  outline:none;border-color:var(--green-600);box-shadow:var(--ring-focus);}
.am-field-input:disabled,.am-field-select:disabled{background:var(--cream-100);color:var(--ink-400);cursor:not-allowed;}
.am-field-input[data-invalid="true"],.am-field-select[data-invalid="true"],.am-field-textarea[data-invalid="true"]{
  border-color:var(--danger-500);}
.am-select-wrap{position:relative;}
.am-select-wrap::after{content:"";position:absolute;right:14px;top:50%;width:9px;height:9px;
  border-right:2px solid var(--ink-500);border-bottom:2px solid var(--ink-500);
  transform:translateY(-65%) rotate(45deg);pointer-events:none;}
`;
function ensureFieldCSS(){
  if (typeof document!=='undefined' && !document.getElementById('am-field-css')){
    const s=document.createElement('style');s.id='am-field-css';s.textContent=FIELD_CSS;document.head.appendChild(s);
  }
}

/** Text input. Pair with FormField for label/hint/error. */
export function Input({ invalid=false, iconLeft, className='', style, ...rest }) {
  ensureFieldCSS();
  if (iconLeft){
    return (
      <span style={{position:'relative',display:'block',...style}}>
        <span style={{position:'absolute',left:12,top:'50%',transform:'translateY(-50%)',display:'inline-flex',color:'var(--ink-400)'}}>{iconLeft}</span>
        <input className={`am-field-input ${className}`} data-invalid={invalid} style={{paddingLeft:38}} {...rest} />
      </span>
    );
  }
  return <input className={`am-field-input ${className}`} data-invalid={invalid} style={style} {...rest} />;
}
