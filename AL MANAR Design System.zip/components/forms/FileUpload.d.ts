import * as React from 'react';
export interface FileUploadProps extends React.LabelHTMLAttributes<HTMLLabelElement> {
  label?: string;
  hint?: string;
  /** When set, shows the chosen file name + "klik untuk ganti" */
  fileName?: string;
  icon?: React.ReactNode;
}
export function FileUpload(props: FileUploadProps): JSX.Element;
