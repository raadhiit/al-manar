import React from 'react';

/** Field wrapper: label, optional hint, required mark, and error message. */
export function FormField({ label, htmlFor, hint, error, required=false, children, style, ...rest }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:7, ...style }} {...rest}>
      {label && (
        <label htmlFor={htmlFor} style={{ fontFamily:'var(--font-sans)', fontSize:'var(--text-sm)', fontWeight:600, color:'var(--ink-700)' }}>
          {label}{required && <span style={{ color:'var(--danger-500)', marginLeft:3 }}>*</span>}
        </label>
      )}
      {children}
      {error
        ? <span style={{ fontSize:'var(--text-xs)', color:'var(--danger-500)' }}>{error}</span>
        : hint && <span style={{ fontSize:'var(--text-xs)', color:'var(--ink-400)' }}>{hint}</span>}
    </div>
  );
}
