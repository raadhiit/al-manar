import React from 'react';

/** Document upload dropzone for PPDB registration (KK, akta, foto, etc). */
export function FileUpload({ label='Unggah dokumen', hint='PDF / JPG · maks. 2 MB', fileName, icon, style, ...rest }) {
  return (
    <label
      style={{
        display:'flex', alignItems:'center', gap:14, cursor:'pointer',
        border:'1.5px dashed var(--border-strong)', borderRadius:'var(--radius-md)',
        background:'var(--cream-50)', padding:'16px 18px',
        transition:'border-color var(--dur-fast),background var(--dur-fast)', ...style,
      }}
      {...rest}
    >
      <span style={{ display:'inline-flex', alignItems:'center', justifyContent:'center', width:42, height:42, borderRadius:'var(--radius-sm)', background:'var(--green-50)', color:'var(--green-600)', flex:'none' }}>
        {icon || (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        )}
      </span>
      <span style={{ display:'flex', flexDirection:'column', gap:2, minWidth:0 }}>
        <span style={{ fontFamily:'var(--font-sans)', fontWeight:600, fontSize:'var(--text-sm)', color: fileName ? 'var(--green-700)' : 'var(--ink-700)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
          {fileName || label}
        </span>
        <span style={{ fontSize:'var(--text-xs)', color:'var(--ink-400)' }}>{fileName ? 'Klik untuk ganti file' : hint}</span>
      </span>
      <input type="file" style={{ display:'none' }} />
    </label>
  );
}
