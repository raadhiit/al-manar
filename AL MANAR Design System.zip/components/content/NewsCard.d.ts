import * as React from 'react';
export interface NewsCardProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  level?: 'SDIT' | 'TKIT' | 'Yayasan';
  category?: string;
  date?: string;
  title?: string;
  excerpt?: string;
  media?: React.ReactNode;
  href?: string;
  /** Horizontal layout for sidebars / lists */
  compact?: boolean;
}
export function NewsCard(props: NewsCardProps): JSX.Element;
