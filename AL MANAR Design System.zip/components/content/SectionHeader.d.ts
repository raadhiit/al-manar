import * as React from 'react';
export interface SectionHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  eyebrow?: React.ReactNode;
  title?: React.ReactNode;
  lead?: React.ReactNode;
  align?: 'start' | 'center';
  /** Action node (e.g. "Lihat semua" button) shown to the right */
  action?: React.ReactNode;
  /** `onbrand` for green sections */
  tone?: 'default' | 'onbrand';
}
export function SectionHeader(props: SectionHeaderProps): JSX.Element;
