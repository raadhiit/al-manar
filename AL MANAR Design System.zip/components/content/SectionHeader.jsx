import React from 'react';

/** Section heading block: eyebrow + title + optional lead + optional action. */
export function SectionHeader({
  eyebrow,
  title,
  lead,
  align = 'start',     // start | center
  action,
  tone = 'default',    // default | onbrand
  style,
  ...rest
}) {
  const onBrand = tone === 'onbrand';
  const center = align === 'center';
  return (
    <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', gap:24, flexWrap:'wrap', ...style }} {...rest}>
      <div style={{ display:'flex', flexDirection:'column', gap:12, maxWidth:640, textAlign:center?'center':'start', marginInline:center?'auto':0, alignItems:center?'center':'flex-start' }}>
        {eyebrow && (
          <span style={{ display:'inline-flex', alignItems:'center', gap:8, fontFamily:'var(--font-sans)', fontSize:'var(--text-xs)', fontWeight:700, letterSpacing:'0.14em', textTransform:'uppercase', color: onBrand?'var(--gold-300)':'var(--gold-600)' }}>
            <span style={{ width:18, height:2, background:'var(--gold-400)', borderRadius:2 }} />
            {eyebrow}
          </span>
        )}
        {title && (
          <h2 style={{ fontFamily:'var(--font-display)', fontWeight:700, fontSize:'var(--text-3xl)', lineHeight:1.15, letterSpacing:'-0.02em', color: onBrand?'#FBF8F1':'var(--ink-900)', margin:0 }}>{title}</h2>
        )}
        {lead && (
          <p style={{ fontFamily:'var(--font-sans)', fontSize:'var(--text-md)', lineHeight:1.65, color: onBrand?'var(--gold-100)':'var(--ink-500)', margin:0 }}>{lead}</p>
        )}
      </div>
      {action && <div style={{ flex:'none' }}>{action}</div>}
    </div>
  );
}
