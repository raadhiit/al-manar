import React from 'react';

/** Generic surface card with optional media slot and hover lift. */
export function Card({ media, padding = 24, hover = true, interactive = false, children, style, ...rest }) {
  const [h, setH] = React.useState(false);
  return (
    <div
      onMouseEnter={() => hover && setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        display:'flex', flexDirection:'column', background:'var(--surface-card)',
        border:'1px solid var(--border-default)', borderRadius:'var(--radius-lg)', overflow:'hidden',
        boxShadow: h ? 'var(--shadow-md)' : 'var(--shadow-xs)',
        transform: h ? 'translateY(-3px)' : 'none',
        transition:'box-shadow var(--dur-base) var(--ease-soft), transform var(--dur-base) var(--ease-soft), border-color var(--dur-base)',
        borderColor: h ? 'var(--border-strong)' : 'var(--border-default)',
        cursor: interactive ? 'pointer' : 'default', ...style,
      }}
      {...rest}
    >
      {media}
      {children != null && <div style={{ padding }}>{children}</div>}
    </div>
  );
}

/** Styled image placeholder — girih pattern + icon, used until real photos arrive. */
export function MediaPlaceholder({ height = 180, label = 'Foto', tone = 'green', icon, style }) {
  const stroke = tone === 'gold' ? '%23A9791F' : '%23155742';
  const tile = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='52' height='52' viewBox='0 0 52 52'%3E%3Cg fill='none' stroke='${stroke}' stroke-width='1' stroke-opacity='0.18'%3E%3Cpath d='M26 4 L37 15 L48 15 L48 26 L37 37 L37 48 L26 48 L15 37 L4 37 L4 26 L15 15 L15 4 Z'/%3E%3C/g%3E%3C/svg%3E")`;
  return (
    <div style={{ height, background: tone==='gold'?'var(--gold-50)':'var(--green-50)', position:'relative', display:'flex', alignItems:'center', justifyContent:'center', ...style }}>
      <div style={{ position:'absolute', inset:0, backgroundImage:tile }} aria-hidden="true" />
      <div style={{ position:'relative', display:'flex', flexDirection:'column', alignItems:'center', gap:8, color: tone==='gold'?'var(--gold-700)':'var(--green-600)' }}>
        {icon || <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.6"/><path d="m21 15-5-5L5 21"/></svg>}
        <span style={{ fontFamily:'var(--font-sans)', fontSize:'var(--text-xs)', fontWeight:600, opacity:.85 }}>{label}</span>
      </div>
    </div>
  );
}
