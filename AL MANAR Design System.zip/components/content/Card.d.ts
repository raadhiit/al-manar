import * as React from 'react';
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Media node rendered flush at the top (image, placeholder) */
  media?: React.ReactNode;
  padding?: number;
  hover?: boolean;
  interactive?: boolean;
  children?: React.ReactNode;
}
export function Card(props: CardProps): JSX.Element;

export interface MediaPlaceholderProps {
  height?: number;
  label?: string;
  tone?: 'green' | 'gold';
  icon?: React.ReactNode;
  style?: React.CSSProperties;
}
export function MediaPlaceholder(props: MediaPlaceholderProps): JSX.Element;
