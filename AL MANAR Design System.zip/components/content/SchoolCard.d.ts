import * as React from 'react';

/**
 * Split-section promo card for a school level.
 * @startingPoint section="Content" subtitle="SDIT / TKIT promo card with stats + CTA" viewport="700x520"
 */
export interface SchoolCardProps extends React.HTMLAttributes<HTMLElement> {
  level?: 'SDIT' | 'TKIT';
  name?: string;
  tagline?: string;
  description?: string;
  ageRange?: string;
  accreditation?: string;
  /** Bulleted highlight points */
  points?: string[];
  media?: React.ReactNode;
  href?: string;
}
export function SchoolCard(props: SchoolCardProps): JSX.Element;
