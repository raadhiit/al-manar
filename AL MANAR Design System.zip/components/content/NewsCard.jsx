import React from 'react';
import { Badge } from '../core/Badge.jsx';

/** Article / news preview card: media, level badge, date, title, excerpt. */
export function NewsCard({
  level,                  // 'SDIT' | 'TKIT' | 'Yayasan'
  category = 'Berita',
  date = '12 Mei 2026',
  title = 'Judul berita kegiatan sekolah',
  excerpt,
  media,
  href = '#',
  compact = false,
  style,
  ...rest
}) {
  const [h, setH] = React.useState(false);
  const levelTone = level === 'TKIT' ? 'tkit' : level === 'SDIT' ? 'sdit' : 'cream';
  return (
    <a
      href={href}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        display:'flex', flexDirection: compact ? 'row' : 'column', gap: compact ? 16 : 0,
        background:'var(--surface-card)', border:'1px solid var(--border-default)',
        borderRadius:'var(--radius-lg)', overflow:'hidden', textDecoration:'none',
        boxShadow: h ? 'var(--shadow-md)' : 'var(--shadow-xs)',
        transform: h ? 'translateY(-3px)' : 'none', borderColor: h?'var(--border-strong)':'var(--border-default)',
        transition:'box-shadow var(--dur-base) var(--ease-soft), transform var(--dur-base) var(--ease-soft), border-color var(--dur-base)',
        ...style,
      }}
      {...rest}
    >
      <div style={{ position:'relative', flex: compact ? '0 0 132px' : 'none' }}>
        {media}
        {!compact && level && <span style={{ position:'absolute', top:14, left:14 }}><Badge tone={levelTone} variant="solid" size="sm">{level}</Badge></span>}
      </div>
      <div style={{ padding: compact ? '14px 16px 14px 0' : '20px 22px 24px', display:'flex', flexDirection:'column', gap:10, minWidth:0 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, fontFamily:'var(--font-sans)', fontSize:'var(--text-xs)', color:'var(--ink-400)' }}>
          {compact && level && <Badge tone={levelTone} variant="soft" size="sm">{level}</Badge>}
          {!compact && <span style={{ fontWeight:700, color:'var(--gold-600)', letterSpacing:'0.06em', textTransform:'uppercase' }}>{category}</span>}
          <span style={{ display:'inline-flex', alignItems:'center', gap:5 }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            {date}
          </span>
        </div>
        <h3 style={{ fontFamily:'var(--font-display)', fontWeight:600, fontSize: compact ? 'var(--text-base)' : 'var(--text-lg)', lineHeight:1.3, color:'var(--ink-900)', margin:0 }}>{title}</h3>
        {excerpt && !compact && <p style={{ fontFamily:'var(--font-sans)', fontSize:'var(--text-sm)', lineHeight:1.6, color:'var(--ink-500)', margin:0, display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical', overflow:'hidden' }}>{excerpt}</p>}
        {!compact && (
          <span style={{ display:'inline-flex', alignItems:'center', gap:6, marginTop:2, fontFamily:'var(--font-sans)', fontSize:'var(--text-sm)', fontWeight:600, color:'var(--green-600)' }}>
            Baca selengkapnya
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
          </span>
        )}
      </div>
    </a>
  );
}
