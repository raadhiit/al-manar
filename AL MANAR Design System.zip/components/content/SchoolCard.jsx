import React from 'react';
import { Badge } from '../core/Badge.jsx';
import { Button } from '../core/Button.jsx';

/** Split-section card promoting a school level (SDIT / TKIT). */
export function SchoolCard({
  level = 'SDIT',                 // 'SDIT' | 'TKIT'
  name = 'SDIT AL MANAR',
  tagline = 'Sekolah Dasar Islam Terpadu',
  description,
  ageRange = '7–12 tahun',
  accreditation = 'A',
  points = [],
  media,
  href = '#',
  style,
  ...rest
}) {
  const tkit = level === 'TKIT';
  const accent = tkit ? 'var(--gold-400)' : 'var(--green-600)';
  return (
    <article
      style={{
        display:'flex', flexDirection:'column', background:'var(--surface-card)',
        border:'1px solid var(--border-default)', borderRadius:'var(--radius-xl)', overflow:'hidden',
        boxShadow:'var(--shadow-sm)', ...style,
      }}
      {...rest}
    >
      <div style={{ position:'relative' }}>
        {media}
        <span style={{ position:'absolute', top:16, left:16 }}>
          <Badge tone={tkit ? 'tkit' : 'sdit'} variant="solid" size="md">{level}</Badge>
        </span>
        <span style={{ position:'absolute', top:16, right:16 }}>
          <Badge tone="cream" variant="solid" size="md">Akreditasi {accreditation}</Badge>
        </span>
      </div>
      <div style={{ padding:'26px 26px 28px', display:'flex', flexDirection:'column', gap:14 }}>
        <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
          <span style={{ fontFamily:'var(--font-sans)', fontSize:'var(--text-xs)', fontWeight:600, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--ink-400)' }}>{tagline}</span>
          <h3 style={{ fontFamily:'var(--font-display)', fontWeight:700, fontSize:'var(--text-2xl)', color:'var(--ink-900)', margin:0 }}>{name}</h3>
        </div>
        {description && <p style={{ fontFamily:'var(--font-sans)', fontSize:'var(--text-base)', lineHeight:1.65, color:'var(--ink-500)', margin:0 }}>{description}</p>}
        {points.length > 0 && (
          <ul style={{ listStyle:'none', margin:'4px 0 0', padding:0, display:'flex', flexDirection:'column', gap:9 }}>
            {points.map((p) => (
              <li key={p} style={{ display:'flex', gap:10, alignItems:'flex-start', fontFamily:'var(--font-sans)', fontSize:'var(--text-sm)', color:'var(--ink-700)' }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={accent} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" style={{ flex:'none', marginTop:1 }}><polyline points="20 6 9 17 4 12"/></svg>
                {p}
              </li>
            ))}
          </ul>
        )}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:16, marginTop:8, paddingTop:18, borderTop:'1px solid var(--border-subtle)' }}>
          <span style={{ fontFamily:'var(--font-sans)', fontSize:'var(--text-sm)', color:'var(--ink-500)' }}>Usia <strong style={{ color:'var(--ink-900)' }}>{ageRange}</strong></span>
          <Button variant={tkit ? 'secondary' : 'primary'} size="sm" href={href}>Profil Sekolah</Button>
        </div>
      </div>
    </article>
  );
}
