import React from 'react';

/**
 * AL MANAR brand lockup — emblem (Rub el Hizb 8-point star + mihrab arch)
 * with optional wordmark and Arabic accent. Self-contained SVG, no asset deps.
 */
export function Logo({
  variant = 'full',        // 'full' | 'mark' | 'stacked'
  tone = 'dark',           // 'dark' (for light bg) | 'light' (for green bg)
  size = 44,
  subtitle = 'Yayasan · Kota Bekasi',
  showArabic = false,
  style,
  ...rest
}) {
  const light = tone === 'light';
  const wordColor = light ? '#FBF8F1' : 'var(--green-700)';
  const subColor = light ? 'var(--gold-300)' : 'var(--ink-500)';
  const boxFill = variant === 'mark' || !light ? '#155742' : 'none';

  const Mark = (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-label="AL MANAR" style={{ flex: 'none', display: 'block' }}>
      <rect x="0" y="0" width="64" height="64" rx="16" fill={light ? 'none' : '#155742'} />
      <g fill="none" stroke="#D9AB3D" strokeWidth="2.4" strokeLinejoin="round">
        <rect x="13" y="13" width="38" height="38" />
        <path d="M32 7 L57 32 L32 57 L7 32 Z" />
      </g>
      <polygon
        points="43.1,36.6 36.6,43.1 27.4,43.1 20.9,36.6 20.9,27.4 27.4,20.9 36.6,20.9 43.1,27.4"
        fill="#D9AB3D" fillOpacity="0.18"
      />
      <path d="M32 22 C27 22 27 28 27 34 L27 42 L37 42 L37 34 C37 28 37 22 32 22 Z" fill="#FBF8F1" />
      <circle cx="32" cy="18.5" r="2.6" fill="#D9AB3D" />
    </svg>
  );

  if (variant === 'mark') {
    return <span style={{ display: 'inline-flex', ...style }} {...rest}>{Mark}</span>;
  }

  const stacked = variant === 'stacked';
  return (
    <span
      style={{
        display: 'inline-flex',
        flexDirection: stacked ? 'column' : 'row',
        alignItems: 'center',
        gap: stacked ? 10 : 12,
        ...style,
      }}
      {...rest}
    >
      {Mark}
      <span style={{ display: 'flex', flexDirection: 'column', lineHeight: 1, alignItems: stacked ? 'center' : 'flex-start' }}>
        <span style={{ display: 'inline-flex', alignItems: 'baseline', gap: 8 }}>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: size * 0.5, letterSpacing: '0.02em', color: wordColor }}>
            AL MANAR
          </span>
          {showArabic && (
            <span style={{ fontFamily: 'var(--font-arabic)', fontSize: size * 0.62, color: light ? 'var(--gold-300)' : 'var(--green-600)', direction: 'rtl' }}>
              المنار
            </span>
          )}
        </span>
        {subtitle && (
          <span style={{ fontFamily: 'var(--font-sans)', fontSize: Math.max(9, size * 0.21), letterSpacing: '0.16em', textTransform: 'uppercase', color: subColor, marginTop: 5 }}>
            {subtitle}
          </span>
        )}
      </span>
    </span>
  );
}
