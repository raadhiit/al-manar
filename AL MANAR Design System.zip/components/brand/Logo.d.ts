import * as React from 'react';

export interface LogoProps {
  /** Lockup layout */
  variant?: 'full' | 'mark' | 'stacked';
  /** 'dark' for light backgrounds, 'light' for green/dark backgrounds */
  tone?: 'dark' | 'light';
  /** Emblem size in px (wordmark scales from this) */
  size?: number;
  /** Sub-label under the wordmark; pass '' to hide */
  subtitle?: string;
  /** Show المنار Arabic accent beside the wordmark */
  showArabic?: boolean;
  style?: React.CSSProperties;
}

export function Logo(props: LogoProps): JSX.Element;
