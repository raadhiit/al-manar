import React from 'react';

/**
 * Decorative Islamic geometric band (8-point girih tile) used behind brand
 * sections, hero edges, and CTA strips. Subtle, single-color, low opacity.
 */
export function PatternBand({
  tone = 'green',          // 'green' | 'cream' | 'gold'
  height = 120,
  opacity = 1,
  children,
  style,
  ...rest
}) {
  const bg =
    tone === 'green' ? 'var(--green-700)' :
    tone === 'gold' ? 'var(--gold-400)' : 'var(--cream-100)';
  const stroke = tone === 'cream' ? '%23155742' : '%23FBF8F1';
  const strokeOpacity = tone === 'cream' ? '0.14' : '0.10';
  const tile =
    `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='56' height='56' viewBox='0 0 56 56'%3E%3Cg fill='none' stroke='${stroke}' stroke-width='1' stroke-opacity='${strokeOpacity}'%3E%3Cpath d='M28 4 L40 16 L52 16 L52 28 L40 40 L40 52 L28 52 L16 40 L4 40 L4 28 L16 16 L16 4 Z'/%3E%3Cpath d='M28 14 L42 28 L28 42 L14 28 Z'/%3E%3C/g%3E%3C/svg%3E")`;

  return (
    <div
      style={{
        position: 'relative',
        minHeight: height,
        background: bg,
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        ...style,
      }}
      {...rest}
    >
      <div style={{ position: 'absolute', inset: 0, backgroundImage: tile, opacity }} aria-hidden="true" />
      {children && <div style={{ position: 'relative', zIndex: 1 }}>{children}</div>}
    </div>
  );
}
