import * as React from 'react';

export interface PatternBandProps {
  /** Background tone the girih tile sits on */
  tone?: 'green' | 'cream' | 'gold';
  /** Min height in px */
  height?: number;
  /** Pattern layer opacity (0–1) */
  opacity?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export function PatternBand(props: PatternBandProps): JSX.Element;
