Brand lockup for AL MANAR — emblem + wordmark, used in navbars, footers, and hero areas.

```jsx
<Logo variant="full" tone="dark" size={44} />
<Logo variant="stacked" tone="light" showArabic subtitle="Yayasan · Kota Bekasi" />
<Logo variant="mark" size={32} />
```

Use `tone="light"` on green/dark surfaces, `tone="dark"` on cream/white. `variant="mark"` is the emblem alone for tight spaces (favicons, mobile bars).
