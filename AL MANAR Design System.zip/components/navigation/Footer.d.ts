import * as React from 'react';
export interface FooterProps extends React.HTMLAttributes<HTMLElement> {}
export function Footer(props: FooterProps): JSX.Element;
