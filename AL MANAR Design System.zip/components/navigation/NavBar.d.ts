import * as React from 'react';

export interface NavItem {
  label: string;
  href?: string;
  active?: boolean;
  children?: { label: string; desc?: string; href?: string }[];
}

/**
 * Primary site navigation.
 * @startingPoint section="Navigation" subtitle="Sticky navbar with SEKOLAH dropdown + mobile menu" viewport="1280x150"
 */
export interface NavBarProps extends React.HTMLAttributes<HTMLElement> {
  items?: NavItem[];
  /** Show the green utility strip with greeting + contact */
  topbar?: boolean;
  ctaLabel?: string;
  onCta?: () => void;
  /** Called when any nav link/dropdown item is clicked (preventsDefault). Receives the item. */
  onNavigate?: (item: NavItem | { key?: string; label?: string; href?: string }, e: React.MouseEvent) => void;
}

export function NavBar(props: NavBarProps): JSX.Element;
