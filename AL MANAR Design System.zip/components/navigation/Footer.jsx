import React from 'react';
import { Logo } from '../brand/Logo.jsx';

/** Site footer: brand block, link columns, contact, and copyright strip. */
export function Footer({ style, ...rest }) {
  const cols = [
    { title:'Sekolah', links:['SDIT AL MANAR','TKIT AL MANAR','Profil Yayasan','Visi & Misi','Struktur Organisasi'] },
    { title:'Informasi', links:['Berita','Prestasi','Galeri','Agenda Kegiatan','Portal Akademik'] },
    { title:'PPDB', links:['Alur Pendaftaran','Jadwal & Biaya','Formulir Online','Unduh Brosur','FAQ'] },
  ];
  return (
    <footer style={{ background:'var(--green-900)', color:'var(--text-on-brand)', ...style }} {...rest}>
      <div style={{ maxWidth:'var(--container-max)', margin:'0 auto', padding:'56px var(--gutter) 0', display:'grid', gridTemplateColumns:'1.4fr repeat(3, 1fr)', gap:40 }} className="am-foot-grid">
        <div style={{ display:'flex', flexDirection:'column', gap:18, maxWidth:320 }}>
          <Logo variant="full" tone="light" size={44} subtitle="Yayasan · Kota Bekasi" />
          <p style={{ fontSize:'var(--text-sm)', color:'var(--gold-100)', opacity:.8, lineHeight:1.7 }}>
            Lembaga pendidikan Islam terpadu yang membentuk generasi berakhlak mulia, berprestasi, dan cinta Al-Qur'an di Kota Bekasi.
          </p>
          <div style={{ display:'flex', gap:10 }}>
            {['instagram','facebook','youtube'].map((s) => (
              <span key={s} style={{ width:38, height:38, borderRadius:'50%', border:'1px solid rgba(217,171,61,0.4)', display:'inline-flex', alignItems:'center', justifyContent:'center', color:'var(--gold-300)' }}>
                <span style={{ width:8, height:8, borderRadius:s==='youtube'?'3px':'50%', background:'currentColor' }} />
              </span>
            ))}
          </div>
        </div>
        {cols.map((c) => (
          <div key={c.title} style={{ display:'flex', flexDirection:'column', gap:14 }}>
            <h4 style={{ fontFamily:'var(--font-sans)', fontSize:'var(--text-sm)', fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--gold-300)', margin:0 }}>{c.title}</h4>
            <ul style={{ listStyle:'none', margin:0, padding:0, display:'flex', flexDirection:'column', gap:10 }}>
              {c.links.map((l) => (
                <li key={l}><a href="#" style={{ color:'var(--gold-100)', opacity:.78, fontSize:'var(--text-sm)', textDecoration:'none' }}>{l}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div style={{ maxWidth:'var(--container-max)', margin:'40px auto 0', padding:'20px var(--gutter)', borderTop:'1px solid rgba(217,171,61,0.22)', display:'flex', justifyContent:'space-between', flexWrap:'wrap', gap:12, fontSize:'var(--text-xs)', color:'var(--gold-100)', opacity:.7 }}>
        <span>© 2026 Yayasan AL MANAR Kota Bekasi. Hak cipta dilindungi.</span>
        <span style={{ display:'inline-flex', gap:18 }}><a href="#" style={{ color:'inherit' }}>Kebijakan Privasi</a><a href="#" style={{ color:'inherit' }}>Syarat & Ketentuan</a></span>
      </div>
    </footer>
  );
}
