import React, { useState } from 'react';
import { Logo } from '../brand/Logo.jsx';
import { Button } from '../core/Button.jsx';

const NAV_CSS = `
.am-nav-link{font-family:var(--font-sans);font-size:var(--text-sm);font-weight:600;color:var(--ink-700);
  text-decoration:none;padding:8px 2px;position:relative;cursor:pointer;white-space:nowrap;background:none;border:0;}
.am-nav-link::after{content:"";position:absolute;left:0;right:0;bottom:-2px;height:2px;background:var(--gold-400);
  transform:scaleX(0);transform-origin:left;transition:transform var(--dur-fast) var(--ease-soft);}
.am-nav-link:hover{color:var(--green-700);}
.am-nav-link:hover::after,.am-nav-link[data-active="true"]::after{transform:scaleX(1);}
.am-nav-link[data-active="true"]{color:var(--green-700);}
.am-nav-drop{position:absolute;top:calc(100% + 10px);left:0;min-width:230px;background:#fff;border:1px solid var(--border-default);
  border-radius:var(--radius-md);box-shadow:var(--shadow-md);padding:8px;opacity:0;visibility:hidden;transform:translateY(-6px);
  transition:all var(--dur-fast) var(--ease-soft);z-index:60;}
.am-nav-dropwrap:hover .am-nav-drop,.am-nav-drop:hover{opacity:1;visibility:visible;transform:translateY(0);}
.am-drop-item{display:flex;gap:10px;align-items:center;padding:10px 12px;border-radius:var(--radius-sm);text-decoration:none;color:var(--ink-700);}
.am-drop-item:hover{background:var(--green-50);}
.am-burger{display:none;background:none;border:1px solid var(--border-default);border-radius:var(--radius-sm);width:42px;height:42px;align-items:center;justify-content:center;cursor:pointer;color:var(--green-700);}
@media(max-width:960px){.am-nav-desktop{display:none !important;}.am-burger{display:inline-flex;}}
`;
function ensureNavCSS(){
  if (typeof document!=='undefined' && !document.getElementById('am-nav-css')){
    const s=document.createElement('style');s.id='am-nav-css';s.textContent=NAV_CSS;document.head.appendChild(s);
  }
}

const DEFAULT_ITEMS = [
  { label:'Beranda', href:'#', active:true },
  { label:'Berita', href:'#' },
  { label:'Prestasi', href:'#' },
  { label:'Galeri', href:'#' },
  { label:'Sekolah', href:'#', children:[
    { label:'SDIT AL MANAR', desc:'Sekolah Dasar Islam Terpadu', href:'#' },
    { label:'TKIT AL MANAR', desc:'TK Islam Terpadu', href:'#' },
  ]},
  { label:'Portal Akademik', href:'#' },
  { label:'Kontak', href:'#' },
];

/** Primary site navigation with SEKOLAH dropdown, utility top strip, and mobile menu. */
export function NavBar({ items = DEFAULT_ITEMS, topbar = true, ctaLabel = 'Daftar Sekarang', onCta, onNavigate, style, ...rest }) {
  ensureNavCSS();
  const [open, setOpen] = useState(false);
  const nav = (item, e) => { if (onNavigate) { e.preventDefault(); onNavigate(item, e); setOpen(false); } };

  return (
    <header style={{ position:'sticky', top:0, zIndex:50, ...style }} {...rest}>
      {topbar && (
        <div style={{ background:'var(--green-800)', color:'var(--gold-200)', fontSize:'var(--text-xs)', fontFamily:'var(--font-sans)' }}>
          <div style={{ maxWidth:'var(--container-max)', margin:'0 auto', padding:'7px var(--gutter)', display:'flex', justifyContent:'space-between', alignItems:'center', gap:16 }}>
            <span style={{ display:'inline-flex', alignItems:'center', gap:8 }}>
              <span className="am-arabic" style={{ fontSize:'14px', color:'var(--gold-300)' }}>السلام عليكم</span>
              <span style={{ opacity:.85 }}>Selamat datang di Yayasan AL MANAR Kota Bekasi</span>
            </span>
            <span style={{ display:'inline-flex', gap:18, alignItems:'center' }}>
              <span style={{ opacity:.85 }}>(021) 8273-xxxx</span>
              <span style={{ opacity:.85 }}>ppdb@almanar.sch.id</span>
            </span>
          </div>
        </div>
      )}
      <div style={{ background:'rgba(251,248,241,0.92)', backdropFilter:'blur(8px)', borderBottom:'1px solid var(--border-subtle)' }}>
        <div style={{ maxWidth:'var(--container-max)', margin:'0 auto', padding:'0 var(--gutter)', height:'var(--navbar-h)', display:'flex', alignItems:'center', justifyContent:'space-between', gap:24 }}>
          <a href="#" onClick={(e) => nav({ key:'home' }, e)} style={{ display:'flex', textDecoration:'none' }}><Logo variant="full" tone="dark" size={42} subtitle="Yayasan · Kota Bekasi" /></a>

          <nav className="am-nav-desktop" style={{ display:'flex', alignItems:'center', gap:26 }}>
            {items.map((it) => it.children ? (
              <span key={it.label} className="am-nav-dropwrap" style={{ position:'relative' }}>
                <button className="am-nav-link" data-active={it.active} style={{ display:'inline-flex', alignItems:'center', gap:5 }}>
                  {it.label}
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="6 9 12 15 18 9"/></svg>
                </button>
                <div className="am-nav-drop">
                  {it.children.map((c) => (
                    <a key={c.label} href={c.href} onClick={(e) => nav(c, e)} className="am-drop-item">
                      <span style={{ width:8, height:8, borderRadius:'50%', background:'var(--gold-400)', flex:'none' }} />
                      <span style={{ display:'flex', flexDirection:'column' }}>
                        <span style={{ fontWeight:700, fontSize:'var(--text-sm)', color:'var(--green-800)' }}>{c.label}</span>
                        <span style={{ fontSize:'var(--text-xs)', color:'var(--ink-500)' }}>{c.desc}</span>
                      </span>
                    </a>
                  ))}
                </div>
              </span>
            ) : (
              <a key={it.label} href={it.href} onClick={(e) => nav(it, e)} className="am-nav-link" data-active={it.active}>{it.label}</a>
            ))}
          </nav>

          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <span className="am-nav-desktop"><Button variant="primary" size="sm" onClick={onCta}>{ctaLabel}</Button></span>
            <button className="am-burger" aria-label="Menu" onClick={() => setOpen((v) => !v)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
            </button>
          </div>
        </div>

        {open && (
          <div style={{ borderTop:'1px solid var(--border-subtle)', background:'var(--cream-50)', padding:'12px var(--gutter) 18px' }}>
            <div style={{ maxWidth:'var(--container-max)', margin:'0 auto', display:'flex', flexDirection:'column', gap:4 }}>
              {items.map((it) => (
                <a key={it.label} href={it.href} onClick={(e) => nav(it, e)} className="am-nav-link" data-active={it.active} style={{ padding:'12px 4px', borderBottom:'1px solid var(--border-subtle)' }}>{it.label}</a>
              ))}
              <div style={{ marginTop:12 }}><Button variant="primary" block onClick={onCta}>{ctaLabel}</Button></div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
