Sticky primary navigation for the AL MANAR site, with a green utility strip, SEKOLAH dropdown (SDIT/TKIT), a Daftar CTA, and a mobile hamburger menu.

```jsx
<NavBar
  items={[
    { label:'Beranda', href:'/', active:true },
    { label:'Berita', href:'/berita' },
    { label:'Sekolah', children:[
      { label:'SDIT AL MANAR', desc:'Sekolah Dasar Islam Terpadu', href:'/sdit' },
      { label:'TKIT AL MANAR', desc:'TK Islam Terpadu', href:'/tk' },
    ]},
  ]}
  ctaLabel="Daftar Sekarang"
/>
```

Collapses to a hamburger under 960px. Pass `topbar={false}` to drop the greeting strip.
