import * as React from 'react';

/**
 * Primary call-to-action button for the AL MANAR site.
 * @startingPoint section="Core" subtitle="Pill buttons in 5 variants + 3 sizes" viewport="700x220"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style */
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'onbrand';
  /** Size */
  size?: 'sm' | 'md' | 'lg';
  /** Stretch to full container width */
  block?: boolean;
  /** Icon node before the label */
  iconLeft?: React.ReactNode;
  /** Icon node after the label */
  iconRight?: React.ReactNode;
  /** Render as a link */
  href?: string;
  children?: React.ReactNode;
}

export function Button(props: ButtonProps): JSX.Element;
