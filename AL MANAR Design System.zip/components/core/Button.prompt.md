Pill-style buttons — the primary CTA across the AL MANAR site ("Daftar Sekarang", "Selengkapnya").

```jsx
<Button variant="primary" size="lg">Daftar Sekarang</Button>
<Button variant="secondary">PPDB 2026</Button>
<Button variant="outline" iconRight={<Icon name="arrow-right" />}>Selengkapnya</Button>
<Button variant="onbrand">Hubungi Kami</Button>   {/* use on green surfaces */}
```

Variants: `primary` (green), `secondary` (gold), `outline`, `ghost`, `onbrand` (cream, for dark green sections). Sizes `sm|md|lg`. Pass `href` to render an anchor.
