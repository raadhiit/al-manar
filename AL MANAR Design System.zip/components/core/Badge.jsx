import React from 'react';

/**
 * Badge — compact status / level marker. Used for school levels (SDIT/TKIT),
 * accreditation grade (A), news categories, and PPDB status.
 */
export function Badge({
  tone = 'green',     // green | gold | cream | success | info | danger | sdit | tkit
  variant = 'soft',   // soft | solid | outline
  size = 'md',        // sm | md
  iconLeft,
  children,
  style,
  ...rest
}) {
  const palettes = {
    green:  { solid: ['var(--green-600)', '#FBF8F1'], soft: ['var(--green-50)', 'var(--green-700)'] },
    gold:   { solid: ['var(--gold-400)', 'var(--green-900)'], soft: ['var(--gold-50)', 'var(--gold-700)'] },
    cream:  { solid: ['var(--cream-200)', 'var(--ink-700)'], soft: ['var(--cream-100)', 'var(--ink-700)'] },
    success:{ solid: ['var(--success-500)', '#fff'], soft: ['var(--success-50)', 'var(--success-500)'] },
    info:   { solid: ['var(--info-500)', '#fff'], soft: ['var(--info-50)', 'var(--info-500)'] },
    danger: { solid: ['var(--danger-500)', '#fff'], soft: ['var(--danger-50)', 'var(--danger-500)'] },
    sdit:   { solid: ['var(--green-600)', '#FBF8F1'], soft: ['var(--green-50)', 'var(--green-700)'] },
    tkit:   { solid: ['var(--gold-400)', 'var(--green-900)'], soft: ['var(--gold-50)', 'var(--gold-700)'] },
  };
  const p = palettes[tone] || palettes.green;
  const [bg, fg] = variant === 'solid' ? p.solid : p.soft;
  const isOutline = variant === 'outline';

  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', gap: '.4em',
        fontFamily: 'var(--font-sans)', fontWeight: 600,
        fontSize: size === 'sm' ? '0.6875rem' : 'var(--text-xs)',
        letterSpacing: '0.04em',
        padding: size === 'sm' ? '.25em .6em' : '.35em .75em',
        borderRadius: 'var(--radius-pill)',
        background: isOutline ? 'transparent' : bg,
        color: isOutline ? p.soft[1] : fg,
        border: isOutline ? `1px solid ${p.solid[0]}` : '1px solid transparent',
        lineHeight: 1.1, whiteSpace: 'nowrap',
        ...style,
      }}
      {...rest}
    >
      {iconLeft}
      {children}
    </span>
  );
}
