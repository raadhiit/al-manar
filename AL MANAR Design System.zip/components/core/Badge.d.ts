import * as React from 'react';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Color intent. `sdit`/`tkit` map to the two school-level brand colors. */
  tone?: 'green' | 'gold' | 'cream' | 'success' | 'info' | 'danger' | 'sdit' | 'tkit';
  /** Fill style */
  variant?: 'soft' | 'solid' | 'outline';
  size?: 'sm' | 'md';
  iconLeft?: React.ReactNode;
  children?: React.ReactNode;
}

export function Badge(props: BadgeProps): JSX.Element;
