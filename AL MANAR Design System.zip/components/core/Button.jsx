import React from 'react';

const CSS = `
.am-btn{font-family:var(--font-sans);font-weight:600;display:inline-flex;align-items:center;justify-content:center;
  gap:.55em;border:1px solid transparent;border-radius:var(--radius-pill);cursor:pointer;text-decoration:none;
  white-space:nowrap;transition:background var(--dur-fast) var(--ease-soft),color var(--dur-fast),
  border-color var(--dur-fast),transform var(--dur-fast),box-shadow var(--dur-fast);line-height:1;}
.am-btn:active{transform:translateY(1px);}
.am-btn[disabled]{opacity:.5;cursor:not-allowed;transform:none;}
.am-btn--sm{font-size:var(--text-sm);padding:.55em 1.05em;height:38px;}
.am-btn--md{font-size:var(--text-base);padding:.7em 1.4em;height:46px;}
.am-btn--lg{font-size:var(--text-md);padding:.85em 1.7em;height:54px;}
.am-btn--primary{background:var(--green-600);color:var(--color-on-primary);box-shadow:var(--shadow-sm);}
.am-btn--primary:hover:not([disabled]){background:var(--green-700);}
.am-btn--secondary{background:var(--gold-400);color:var(--green-900);box-shadow:var(--shadow-sm);}
.am-btn--secondary:hover:not([disabled]){background:var(--gold-500);}
.am-btn--outline{background:transparent;color:var(--green-700);border-color:var(--border-strong);}
.am-btn--outline:hover:not([disabled]){border-color:var(--green-600);background:var(--green-50);}
.am-btn--ghost{background:transparent;color:var(--green-700);}
.am-btn--ghost:hover:not([disabled]){background:var(--green-50);}
.am-btn--onbrand{background:#FBF8F1;color:var(--green-800);}
.am-btn--onbrand:hover:not([disabled]){background:#fff;}
.am-btn--block{width:100%;}
`;

let injected = false;
function useBtnCSS() {
  if (typeof document !== 'undefined' && !injected) {
    const s = document.createElement('style');
    s.id = 'am-btn-css';
    s.textContent = CSS;
    document.head.appendChild(s);
    injected = true;
  }
}

/** Primary CTA element across the AL MANAR site. Renders <a> when href is set. */
export function Button({
  variant = 'primary',   // primary | secondary | outline | ghost | onbrand
  size = 'md',           // sm | md | lg
  block = false,
  iconLeft,
  iconRight,
  href,
  children,
  className = '',
  ...rest
}) {
  useBtnCSS();
  const Tag = href ? 'a' : 'button';
  const cls = `am-btn am-btn--${variant} am-btn--${size}${block ? ' am-btn--block' : ''} ${className}`.trim();
  return (
    <Tag className={cls} href={href} {...rest}>
      {iconLeft}
      {children}
      {iconRight}
    </Tag>
  );
}
