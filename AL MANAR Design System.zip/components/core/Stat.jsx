import React from 'react';

/**
 * Stat — a single figure with label, for achievement/figure strips.
 * e.g. "1.200+ Alumni", "32 Prestasi", "A Akreditasi".
 */
export function Stat({
  value,
  label,
  sublabel,
  align = 'start',     // start | center
  tone = 'green',      // green | gold | onbrand
  style,
  ...rest
}) {
  const valueColor =
    tone === 'gold' ? 'var(--gold-500)' :
    tone === 'onbrand' ? '#FBF8F1' : 'var(--green-700)';
  const labelColor = tone === 'onbrand' ? 'var(--gold-200)' : 'var(--ink-500)';
  return (
    <div
      style={{ display: 'flex', flexDirection: 'column', gap: 4, textAlign: align, alignItems: align === 'center' ? 'center' : 'flex-start', ...style }}
      {...rest}
    >
      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--text-4xl)', lineHeight: 1, letterSpacing: '-0.02em', color: valueColor }}>
        {value}
      </span>
      <span style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 'var(--text-sm)', color: tone === 'onbrand' ? '#FBF8F1' : 'var(--ink-700)' }}>
        {label}
      </span>
      {sublabel && (
        <span style={{ fontFamily: 'var(--font-sans)', fontSize: 'var(--text-xs)', color: labelColor }}>{sublabel}</span>
      )}
    </div>
  );
}
