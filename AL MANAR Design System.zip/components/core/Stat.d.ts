import * as React from 'react';

export interface StatProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The figure, e.g. "1.200+" or "A" */
  value?: React.ReactNode;
  /** Primary label under the figure */
  label?: React.ReactNode;
  /** Optional smaller caption */
  sublabel?: React.ReactNode;
  align?: 'start' | 'center';
  /** `onbrand` for use on green surfaces */
  tone?: 'green' | 'gold' | 'onbrand';
}

export function Stat(props: StatProps): JSX.Element;
