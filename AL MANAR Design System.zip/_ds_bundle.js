/* @ds-bundle: {"format":3,"namespace":"ALMANARDesignSystem_a019ff","components":[{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"PatternBand","sourcePath":"components/brand/PatternBand.jsx"},{"name":"Card","sourcePath":"components/content/Card.jsx"},{"name":"MediaPlaceholder","sourcePath":"components/content/Card.jsx"},{"name":"NewsCard","sourcePath":"components/content/NewsCard.jsx"},{"name":"SchoolCard","sourcePath":"components/content/SchoolCard.jsx"},{"name":"SectionHeader","sourcePath":"components/content/SectionHeader.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Stat","sourcePath":"components/core/Stat.jsx"},{"name":"FileUpload","sourcePath":"components/forms/FileUpload.jsx"},{"name":"FormField","sourcePath":"components/forms/FormField.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"}],"sourceHashes":{"components/brand/Logo.jsx":"00653fd344d3","components/brand/PatternBand.jsx":"254e5c76eb61","components/content/Card.jsx":"5134782a3352","components/content/NewsCard.jsx":"f2c34e271e5d","components/content/SchoolCard.jsx":"4a47b68943e5","components/content/SectionHeader.jsx":"edef0b76e924","components/core/Badge.jsx":"57c0a9c04222","components/core/Button.jsx":"f6f109d2cf33","components/core/Stat.jsx":"2552133aed21","components/forms/FileUpload.jsx":"54e511e3e1af","components/forms/FormField.jsx":"abcafc99225f","components/forms/Input.jsx":"99dd3662c52e","components/forms/Select.jsx":"b201d2506628","components/forms/Textarea.jsx":"98f630d0f1a3","components/navigation/Footer.jsx":"15b69e0c1ed3","components/navigation/NavBar.jsx":"f50c25c4df96","ui_kits/website/app.jsx":"a459827aec95","ui_kits/website/home.jsx":"08a5778ea62c"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ALMANARDesignSystem_a019ff = window.ALMANARDesignSystem_a019ff || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AL MANAR brand lockup — emblem (Rub el Hizb 8-point star + mihrab arch)
 * with optional wordmark and Arabic accent. Self-contained SVG, no asset deps.
 */
function Logo({
  variant = 'full',
  // 'full' | 'mark' | 'stacked'
  tone = 'dark',
  // 'dark' (for light bg) | 'light' (for green bg)
  size = 44,
  subtitle = 'Yayasan · Kota Bekasi',
  showArabic = false,
  style,
  ...rest
}) {
  const light = tone === 'light';
  const wordColor = light ? '#FBF8F1' : 'var(--green-700)';
  const subColor = light ? 'var(--gold-300)' : 'var(--ink-500)';
  const boxFill = variant === 'mark' || !light ? '#155742' : 'none';
  const Mark = /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 64 64",
    "aria-label": "AL MANAR",
    style: {
      flex: 'none',
      display: 'block'
    }
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "0",
    width: "64",
    height: "64",
    rx: "16",
    fill: light ? 'none' : '#155742'
  }), /*#__PURE__*/React.createElement("g", {
    fill: "none",
    stroke: "#D9AB3D",
    strokeWidth: "2.4",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "13",
    y: "13",
    width: "38",
    height: "38"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M32 7 L57 32 L32 57 L7 32 Z"
  })), /*#__PURE__*/React.createElement("polygon", {
    points: "43.1,36.6 36.6,43.1 27.4,43.1 20.9,36.6 20.9,27.4 27.4,20.9 36.6,20.9 43.1,27.4",
    fill: "#D9AB3D",
    fillOpacity: "0.18"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M32 22 C27 22 27 28 27 34 L27 42 L37 42 L37 34 C37 28 37 22 32 22 Z",
    fill: "#FBF8F1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "32",
    cy: "18.5",
    r: "2.6",
    fill: "#D9AB3D"
  }));
  if (variant === 'mark') {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        display: 'inline-flex',
        ...style
      }
    }, rest), Mark);
  }
  const stacked = variant === 'stacked';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      flexDirection: stacked ? 'column' : 'row',
      alignItems: 'center',
      gap: stacked ? 10 : 12,
      ...style
    }
  }, rest), Mark, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1,
      alignItems: stacked ? 'center' : 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'baseline',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: size * 0.5,
      letterSpacing: '0.02em',
      color: wordColor
    }
  }, "AL MANAR"), showArabic && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-arabic)',
      fontSize: size * 0.62,
      color: light ? 'var(--gold-300)' : 'var(--green-600)',
      direction: 'rtl'
    }
  }, "\u0627\u0644\u0645\u0646\u0627\u0631")), subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: Math.max(9, size * 0.21),
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      color: subColor,
      marginTop: 5
    }
  }, subtitle)));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/brand/PatternBand.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Decorative Islamic geometric band (8-point girih tile) used behind brand
 * sections, hero edges, and CTA strips. Subtle, single-color, low opacity.
 */
function PatternBand({
  tone = 'green',
  // 'green' | 'cream' | 'gold'
  height = 120,
  opacity = 1,
  children,
  style,
  ...rest
}) {
  const bg = tone === 'green' ? 'var(--green-700)' : tone === 'gold' ? 'var(--gold-400)' : 'var(--cream-100)';
  const stroke = tone === 'cream' ? '%23155742' : '%23FBF8F1';
  const strokeOpacity = tone === 'cream' ? '0.14' : '0.10';
  const tile = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='56' height='56' viewBox='0 0 56 56'%3E%3Cg fill='none' stroke='${stroke}' stroke-width='1' stroke-opacity='${strokeOpacity}'%3E%3Cpath d='M28 4 L40 16 L52 16 L52 28 L40 40 L40 52 L28 52 L16 40 L4 40 L4 28 L16 16 L16 4 Z'/%3E%3Cpath d='M28 14 L42 28 L28 42 L14 28 Z'/%3E%3C/g%3E%3C/svg%3E")`;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      minHeight: height,
      background: bg,
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: tile,
      opacity
    },
    "aria-hidden": "true"
  }), children && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, children));
}
Object.assign(__ds_scope, { PatternBand });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/PatternBand.jsx", error: String((e && e.message) || e) }); }

// components/content/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Generic surface card with optional media slot and hover lift. */
function Card({
  media,
  padding = 24,
  hover = true,
  interactive = false,
  children,
  style,
  ...rest
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => hover && setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      boxShadow: h ? 'var(--shadow-md)' : 'var(--shadow-xs)',
      transform: h ? 'translateY(-3px)' : 'none',
      transition: 'box-shadow var(--dur-base) var(--ease-soft), transform var(--dur-base) var(--ease-soft), border-color var(--dur-base)',
      borderColor: h ? 'var(--border-strong)' : 'var(--border-default)',
      cursor: interactive ? 'pointer' : 'default',
      ...style
    }
  }, rest), media, children != null && /*#__PURE__*/React.createElement("div", {
    style: {
      padding
    }
  }, children));
}

/** Styled image placeholder — girih pattern + icon, used until real photos arrive. */
function MediaPlaceholder({
  height = 180,
  label = 'Foto',
  tone = 'green',
  icon,
  style
}) {
  const stroke = tone === 'gold' ? '%23A9791F' : '%23155742';
  const tile = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='52' height='52' viewBox='0 0 52 52'%3E%3Cg fill='none' stroke='${stroke}' stroke-width='1' stroke-opacity='0.18'%3E%3Cpath d='M26 4 L37 15 L48 15 L48 26 L37 37 L37 48 L26 48 L15 37 L4 37 L4 26 L15 15 L15 4 Z'/%3E%3C/g%3E%3C/svg%3E")`;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height,
      background: tone === 'gold' ? 'var(--gold-50)' : 'var(--green-50)',
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: tile
    },
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 8,
      color: tone === 'gold' ? 'var(--gold-700)' : 'var(--green-600)'
    }
  }, icon || /*#__PURE__*/React.createElement("svg", {
    width: "30",
    height: "30",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.6"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "3",
    width: "18",
    height: "18",
    rx: "2"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "8.5",
    cy: "8.5",
    r: "1.6"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m21 15-5-5L5 21"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      fontWeight: 600,
      opacity: .85
    }
  }, label)));
}
Object.assign(__ds_scope, { Card, MediaPlaceholder });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Card.jsx", error: String((e && e.message) || e) }); }

// components/content/SectionHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Section heading block: eyebrow + title + optional lead + optional action. */
function SectionHeader({
  eyebrow,
  title,
  lead,
  align = 'start',
  // start | center
  action,
  tone = 'default',
  // default | onbrand
  style,
  ...rest
}) {
  const onBrand = tone === 'onbrand';
  const center = align === 'center';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 24,
      flexWrap: 'wrap',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      maxWidth: 640,
      textAlign: center ? 'center' : 'start',
      marginInline: center ? 'auto' : 0,
      alignItems: center ? 'center' : 'flex-start'
    }
  }, eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      fontWeight: 700,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: onBrand ? 'var(--gold-300)' : 'var(--gold-600)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 2,
      background: 'var(--gold-400)',
      borderRadius: 2
    }
  }), eyebrow), title && /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--text-3xl)',
      lineHeight: 1.15,
      letterSpacing: '-0.02em',
      color: onBrand ? '#FBF8F1' : 'var(--ink-900)',
      margin: 0
    }
  }, title), lead && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-md)',
      lineHeight: 1.65,
      color: onBrand ? 'var(--gold-100)' : 'var(--ink-500)',
      margin: 0
    }
  }, lead)), action && /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 'none'
    }
  }, action));
}
Object.assign(__ds_scope, { SectionHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — compact status / level marker. Used for school levels (SDIT/TKIT),
 * accreditation grade (A), news categories, and PPDB status.
 */
function Badge({
  tone = 'green',
  // green | gold | cream | success | info | danger | sdit | tkit
  variant = 'soft',
  // soft | solid | outline
  size = 'md',
  // sm | md
  iconLeft,
  children,
  style,
  ...rest
}) {
  const palettes = {
    green: {
      solid: ['var(--green-600)', '#FBF8F1'],
      soft: ['var(--green-50)', 'var(--green-700)']
    },
    gold: {
      solid: ['var(--gold-400)', 'var(--green-900)'],
      soft: ['var(--gold-50)', 'var(--gold-700)']
    },
    cream: {
      solid: ['var(--cream-200)', 'var(--ink-700)'],
      soft: ['var(--cream-100)', 'var(--ink-700)']
    },
    success: {
      solid: ['var(--success-500)', '#fff'],
      soft: ['var(--success-50)', 'var(--success-500)']
    },
    info: {
      solid: ['var(--info-500)', '#fff'],
      soft: ['var(--info-50)', 'var(--info-500)']
    },
    danger: {
      solid: ['var(--danger-500)', '#fff'],
      soft: ['var(--danger-50)', 'var(--danger-500)']
    },
    sdit: {
      solid: ['var(--green-600)', '#FBF8F1'],
      soft: ['var(--green-50)', 'var(--green-700)']
    },
    tkit: {
      solid: ['var(--gold-400)', 'var(--green-900)'],
      soft: ['var(--gold-50)', 'var(--gold-700)']
    }
  };
  const p = palettes[tone] || palettes.green;
  const [bg, fg] = variant === 'solid' ? p.solid : p.soft;
  const isOutline = variant === 'outline';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '.4em',
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: size === 'sm' ? '0.6875rem' : 'var(--text-xs)',
      letterSpacing: '0.04em',
      padding: size === 'sm' ? '.25em .6em' : '.35em .75em',
      borderRadius: 'var(--radius-pill)',
      background: isOutline ? 'transparent' : bg,
      color: isOutline ? p.soft[1] : fg,
      border: isOutline ? `1px solid ${p.solid[0]}` : '1px solid transparent',
      lineHeight: 1.1,
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), iconLeft, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/content/NewsCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Article / news preview card: media, level badge, date, title, excerpt. */
function NewsCard({
  level,
  // 'SDIT' | 'TKIT' | 'Yayasan'
  category = 'Berita',
  date = '12 Mei 2026',
  title = 'Judul berita kegiatan sekolah',
  excerpt,
  media,
  href = '#',
  compact = false,
  style,
  ...rest
}) {
  const [h, setH] = React.useState(false);
  const levelTone = level === 'TKIT' ? 'tkit' : level === 'SDIT' ? 'sdit' : 'cream';
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'flex',
      flexDirection: compact ? 'row' : 'column',
      gap: compact ? 16 : 0,
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      textDecoration: 'none',
      boxShadow: h ? 'var(--shadow-md)' : 'var(--shadow-xs)',
      transform: h ? 'translateY(-3px)' : 'none',
      borderColor: h ? 'var(--border-strong)' : 'var(--border-default)',
      transition: 'box-shadow var(--dur-base) var(--ease-soft), transform var(--dur-base) var(--ease-soft), border-color var(--dur-base)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: compact ? '0 0 132px' : 'none'
    }
  }, media, !compact && level && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 14,
      left: 14
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: levelTone,
    variant: "solid",
    size: "sm"
  }, level))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: compact ? '14px 16px 14px 0' : '20px 22px 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      color: 'var(--ink-400)'
    }
  }, compact && level && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: levelTone,
    variant: "soft",
    size: "sm"
  }, level), !compact && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: 'var(--gold-600)',
      letterSpacing: '0.06em',
      textTransform: 'uppercase'
    }
  }, category), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "4",
    width: "18",
    height: "18",
    rx: "2"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "16",
    y1: "2",
    x2: "16",
    y2: "6"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "8",
    y1: "2",
    x2: "8",
    y2: "6"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "3",
    y1: "10",
    x2: "21",
    y2: "10"
  })), date)), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: compact ? 'var(--text-base)' : 'var(--text-lg)',
      lineHeight: 1.3,
      color: 'var(--ink-900)',
      margin: 0
    }
  }, title), excerpt && !compact && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      lineHeight: 1.6,
      color: 'var(--ink-500)',
      margin: 0,
      display: '-webkit-box',
      WebkitLineClamp: 2,
      WebkitBoxOrient: 'vertical',
      overflow: 'hidden'
    }
  }, excerpt), !compact && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      marginTop: 2,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 600,
      color: 'var(--green-600)'
    }
  }, "Baca selengkapnya", /*#__PURE__*/React.createElement("svg", {
    width: "15",
    height: "15",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.4",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "5",
    y1: "12",
    x2: "19",
    y2: "12"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "12 5 19 12 12 19"
  })))));
}
Object.assign(__ds_scope, { NewsCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/NewsCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.am-btn{font-family:var(--font-sans);font-weight:600;display:inline-flex;align-items:center;justify-content:center;
  gap:.55em;border:1px solid transparent;border-radius:var(--radius-pill);cursor:pointer;text-decoration:none;
  white-space:nowrap;transition:background var(--dur-fast) var(--ease-soft),color var(--dur-fast),
  border-color var(--dur-fast),transform var(--dur-fast),box-shadow var(--dur-fast);line-height:1;}
.am-btn:active{transform:translateY(1px);}
.am-btn[disabled]{opacity:.5;cursor:not-allowed;transform:none;}
.am-btn--sm{font-size:var(--text-sm);padding:.55em 1.05em;height:38px;}
.am-btn--md{font-size:var(--text-base);padding:.7em 1.4em;height:46px;}
.am-btn--lg{font-size:var(--text-md);padding:.85em 1.7em;height:54px;}
.am-btn--primary{background:var(--green-600);color:var(--color-on-primary);box-shadow:var(--shadow-sm);}
.am-btn--primary:hover:not([disabled]){background:var(--green-700);}
.am-btn--secondary{background:var(--gold-400);color:var(--green-900);box-shadow:var(--shadow-sm);}
.am-btn--secondary:hover:not([disabled]){background:var(--gold-500);}
.am-btn--outline{background:transparent;color:var(--green-700);border-color:var(--border-strong);}
.am-btn--outline:hover:not([disabled]){border-color:var(--green-600);background:var(--green-50);}
.am-btn--ghost{background:transparent;color:var(--green-700);}
.am-btn--ghost:hover:not([disabled]){background:var(--green-50);}
.am-btn--onbrand{background:#FBF8F1;color:var(--green-800);}
.am-btn--onbrand:hover:not([disabled]){background:#fff;}
.am-btn--block{width:100%;}
`;
let injected = false;
function useBtnCSS() {
  if (typeof document !== 'undefined' && !injected) {
    const s = document.createElement('style');
    s.id = 'am-btn-css';
    s.textContent = CSS;
    document.head.appendChild(s);
    injected = true;
  }
}

/** Primary CTA element across the AL MANAR site. Renders <a> when href is set. */
function Button({
  variant = 'primary',
  // primary | secondary | outline | ghost | onbrand
  size = 'md',
  // sm | md | lg
  block = false,
  iconLeft,
  iconRight,
  href,
  children,
  className = '',
  ...rest
}) {
  useBtnCSS();
  const Tag = href ? 'a' : 'button';
  const cls = `am-btn am-btn--${variant} am-btn--${size}${block ? ' am-btn--block' : ''} ${className}`.trim();
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls,
    href: href
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/content/SchoolCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Split-section card promoting a school level (SDIT / TKIT). */
function SchoolCard({
  level = 'SDIT',
  // 'SDIT' | 'TKIT'
  name = 'SDIT AL MANAR',
  tagline = 'Sekolah Dasar Islam Terpadu',
  description,
  ageRange = '7–12 tahun',
  accreditation = 'A',
  points = [],
  media,
  href = '#',
  style,
  ...rest
}) {
  const tkit = level === 'TKIT';
  const accent = tkit ? 'var(--gold-400)' : 'var(--green-600)';
  return /*#__PURE__*/React.createElement("article", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-xl)',
      overflow: 'hidden',
      boxShadow: 'var(--shadow-sm)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, media, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 16,
      left: 16
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: tkit ? 'tkit' : 'sdit',
    variant: "solid",
    size: "md"
  }, level)), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 16,
      right: 16
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "cream",
    variant: "solid",
    size: "md"
  }, "Akreditasi ", accreditation))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '26px 26px 28px',
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      fontWeight: 600,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--ink-400)'
    }
  }, tagline), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--text-2xl)',
      color: 'var(--ink-900)',
      margin: 0
    }
  }, name)), description && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-base)',
      lineHeight: 1.65,
      color: 'var(--ink-500)',
      margin: 0
    }
  }, description), points.length > 0 && /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: '4px 0 0',
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 9
    }
  }, points.map(p => /*#__PURE__*/React.createElement("li", {
    key: p,
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'flex-start',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      color: 'var(--ink-700)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: accent,
    strokeWidth: "2.4",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      flex: 'none',
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  })), p))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16,
      marginTop: 8,
      paddingTop: 18,
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      color: 'var(--ink-500)'
    }
  }, "Usia ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--ink-900)'
    }
  }, ageRange)), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: tkit ? 'secondary' : 'primary',
    size: "sm",
    href: href
  }, "Profil Sekolah"))));
}
Object.assign(__ds_scope, { SchoolCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/SchoolCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Stat — a single figure with label, for achievement/figure strips.
 * e.g. "1.200+ Alumni", "32 Prestasi", "A Akreditasi".
 */
function Stat({
  value,
  label,
  sublabel,
  align = 'start',
  // start | center
  tone = 'green',
  // green | gold | onbrand
  style,
  ...rest
}) {
  const valueColor = tone === 'gold' ? 'var(--gold-500)' : tone === 'onbrand' ? '#FBF8F1' : 'var(--green-700)';
  const labelColor = tone === 'onbrand' ? 'var(--gold-200)' : 'var(--ink-500)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      textAlign: align,
      alignItems: align === 'center' ? 'center' : 'flex-start',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--text-4xl)',
      lineHeight: 1,
      letterSpacing: '-0.02em',
      color: valueColor
    }
  }, value), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 'var(--text-sm)',
      color: tone === 'onbrand' ? '#FBF8F1' : 'var(--ink-700)'
    }
  }, label), sublabel && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      color: labelColor
    }
  }, sublabel));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stat.jsx", error: String((e && e.message) || e) }); }

// components/forms/FileUpload.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Document upload dropzone for PPDB registration (KK, akta, foto, etc). */
function FileUpload({
  label = 'Unggah dokumen',
  hint = 'PDF / JPG · maks. 2 MB',
  fileName,
  icon,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      cursor: 'pointer',
      border: '1.5px dashed var(--border-strong)',
      borderRadius: 'var(--radius-md)',
      background: 'var(--cream-50)',
      padding: '16px 18px',
      transition: 'border-color var(--dur-fast),background var(--dur-fast)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 42,
      height: 42,
      borderRadius: 'var(--radius-sm)',
      background: 'var(--green-50)',
      color: 'var(--green-600)',
      flex: 'none'
    }
  }, icon || /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "17 8 12 3 7 8"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "3",
    x2: "12",
    y2: "15"
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 'var(--text-sm)',
      color: fileName ? 'var(--green-700)' : 'var(--ink-700)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, fileName || label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--ink-400)'
    }
  }, fileName ? 'Klik untuk ganti file' : hint)), /*#__PURE__*/React.createElement("input", {
    type: "file",
    style: {
      display: 'none'
    }
  }));
}
Object.assign(__ds_scope, { FileUpload });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FileUpload.jsx", error: String((e && e.message) || e) }); }

// components/forms/FormField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Field wrapper: label, optional hint, required mark, and error message. */
function FormField({
  label,
  htmlFor,
  hint,
  error,
  required = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 7,
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement("label", {
    htmlFor: htmlFor,
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 600,
      color: 'var(--ink-700)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--danger-500)',
      marginLeft: 3
    }
  }, "*")), children, error ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--danger-500)'
    }
  }, error) : hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--ink-400)'
    }
  }, hint));
}
Object.assign(__ds_scope, { FormField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FormField.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const FIELD_CSS = `
.am-field-input,.am-field-select,.am-field-textarea{
  width:100%;font-family:var(--font-sans);font-size:var(--text-base);color:var(--ink-900);
  background:#fff;border:1.5px solid var(--border-default);border-radius:var(--radius-md);
  padding:.7em .9em;line-height:1.4;transition:border-color var(--dur-fast),box-shadow var(--dur-fast);
  appearance:none;-webkit-appearance:none;}
.am-field-textarea{min-height:120px;resize:vertical;}
.am-field-input::placeholder,.am-field-textarea::placeholder{color:var(--ink-400);}
.am-field-input:focus,.am-field-select:focus,.am-field-textarea:focus{
  outline:none;border-color:var(--green-600);box-shadow:var(--ring-focus);}
.am-field-input:disabled,.am-field-select:disabled{background:var(--cream-100);color:var(--ink-400);cursor:not-allowed;}
.am-field-input[data-invalid="true"],.am-field-select[data-invalid="true"],.am-field-textarea[data-invalid="true"]{
  border-color:var(--danger-500);}
.am-select-wrap{position:relative;}
.am-select-wrap::after{content:"";position:absolute;right:14px;top:50%;width:9px;height:9px;
  border-right:2px solid var(--ink-500);border-bottom:2px solid var(--ink-500);
  transform:translateY(-65%) rotate(45deg);pointer-events:none;}
`;
function ensureFieldCSS() {
  if (typeof document !== 'undefined' && !document.getElementById('am-field-css')) {
    const s = document.createElement('style');
    s.id = 'am-field-css';
    s.textContent = FIELD_CSS;
    document.head.appendChild(s);
  }
}

/** Text input. Pair with FormField for label/hint/error. */
function Input({
  invalid = false,
  iconLeft,
  className = '',
  style,
  ...rest
}) {
  ensureFieldCSS();
  if (iconLeft) {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'relative',
        display: 'block',
        ...style
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 12,
        top: '50%',
        transform: 'translateY(-50%)',
        display: 'inline-flex',
        color: 'var(--ink-400)'
      }
    }, iconLeft), /*#__PURE__*/React.createElement("input", _extends({
      className: `am-field-input ${className}`,
      "data-invalid": invalid,
      style: {
        paddingLeft: 38
      }
    }, rest)));
  }
  return /*#__PURE__*/React.createElement("input", _extends({
    className: `am-field-input ${className}`,
    "data-invalid": invalid,
    style: style
  }, rest));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Native select, styled to match Input. Pass <option> children. */
function Select({
  invalid = false,
  className = '',
  children,
  style,
  ...rest
}) {
  if (typeof document !== 'undefined' && !document.getElementById('am-field-css')) {
    // FIELD_CSS is injected by Input; ensure presence if Select used alone
    const s = document.createElement('style');
    s.id = 'am-field-css';
    s.textContent = `.am-field-select{width:100%;font-family:var(--font-sans);font-size:var(--text-base);color:var(--ink-900);background:#fff;border:1.5px solid var(--border-default);border-radius:var(--radius-md);padding:.7em 2.2em .7em .9em;line-height:1.4;appearance:none;-webkit-appearance:none;}.am-field-select:focus{outline:none;border-color:var(--green-600);box-shadow:var(--ring-focus);}.am-select-wrap{position:relative;}.am-select-wrap::after{content:"";position:absolute;right:14px;top:50%;width:9px;height:9px;border-right:2px solid var(--ink-500);border-bottom:2px solid var(--ink-500);transform:translateY(-65%) rotate(45deg);pointer-events:none;}`;
    document.head.appendChild(s);
  }
  return /*#__PURE__*/React.createElement("span", {
    className: "am-select-wrap",
    style: {
      display: 'block',
      ...style
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    className: `am-field-select ${className}`,
    "data-invalid": invalid
  }, rest), children));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Multi-line text input, styled to match Input. */
function Textarea({
  invalid = false,
  className = '',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("textarea", _extends({
    className: `am-field-textarea ${className}`,
    "data-invalid": invalid,
    style: style
  }, rest));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Site footer: brand block, link columns, contact, and copyright strip. */
function Footer({
  style,
  ...rest
}) {
  const cols = [{
    title: 'Sekolah',
    links: ['SDIT AL MANAR', 'TKIT AL MANAR', 'Profil Yayasan', 'Visi & Misi', 'Struktur Organisasi']
  }, {
    title: 'Informasi',
    links: ['Berita', 'Prestasi', 'Galeri', 'Agenda Kegiatan', 'Portal Akademik']
  }, {
    title: 'PPDB',
    links: ['Alur Pendaftaran', 'Jadwal & Biaya', 'Formulir Online', 'Unduh Brosur', 'FAQ']
  }];
  return /*#__PURE__*/React.createElement("footer", _extends({
    style: {
      background: 'var(--green-900)',
      color: 'var(--text-on-brand)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '56px var(--gutter) 0',
      display: 'grid',
      gridTemplateColumns: '1.4fr repeat(3, 1fr)',
      gap: 40
    },
    className: "am-foot-grid"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18,
      maxWidth: 320
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    variant: "full",
    tone: "light",
    size: 44,
    subtitle: "Yayasan \xB7 Kota Bekasi"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--gold-100)',
      opacity: .8,
      lineHeight: 1.7
    }
  }, "Lembaga pendidikan Islam terpadu yang membentuk generasi berakhlak mulia, berprestasi, dan cinta Al-Qur'an di Kota Bekasi."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, ['instagram', 'facebook', 'youtube'].map(s => /*#__PURE__*/React.createElement("span", {
    key: s,
    style: {
      width: 38,
      height: 38,
      borderRadius: '50%',
      border: '1px solid rgba(217,171,61,0.4)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--gold-300)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: s === 'youtube' ? '3px' : '50%',
      background: 'currentColor'
    }
  }))))), cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.title,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--gold-300)',
      margin: 0
    }
  }, c.title), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, c.links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'var(--gold-100)',
      opacity: .78,
      fontSize: 'var(--text-sm)',
      textDecoration: 'none'
    }
  }, l))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '40px auto 0',
      padding: '20px var(--gutter)',
      borderTop: '1px solid rgba(217,171,61,0.22)',
      display: 'flex',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
      gap: 12,
      fontSize: 'var(--text-xs)',
      color: 'var(--gold-100)',
      opacity: .7
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Yayasan AL MANAR Kota Bekasi. Hak cipta dilindungi."), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'inherit'
    }
  }, "Kebijakan Privasi"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'inherit'
    }
  }, "Syarat & Ketentuan"))));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
const NAV_CSS = `
.am-nav-link{font-family:var(--font-sans);font-size:var(--text-sm);font-weight:600;color:var(--ink-700);
  text-decoration:none;padding:8px 2px;position:relative;cursor:pointer;white-space:nowrap;background:none;border:0;}
.am-nav-link::after{content:"";position:absolute;left:0;right:0;bottom:-2px;height:2px;background:var(--gold-400);
  transform:scaleX(0);transform-origin:left;transition:transform var(--dur-fast) var(--ease-soft);}
.am-nav-link:hover{color:var(--green-700);}
.am-nav-link:hover::after,.am-nav-link[data-active="true"]::after{transform:scaleX(1);}
.am-nav-link[data-active="true"]{color:var(--green-700);}
.am-nav-drop{position:absolute;top:calc(100% + 10px);left:0;min-width:230px;background:#fff;border:1px solid var(--border-default);
  border-radius:var(--radius-md);box-shadow:var(--shadow-md);padding:8px;opacity:0;visibility:hidden;transform:translateY(-6px);
  transition:all var(--dur-fast) var(--ease-soft);z-index:60;}
.am-nav-dropwrap:hover .am-nav-drop,.am-nav-drop:hover{opacity:1;visibility:visible;transform:translateY(0);}
.am-drop-item{display:flex;gap:10px;align-items:center;padding:10px 12px;border-radius:var(--radius-sm);text-decoration:none;color:var(--ink-700);}
.am-drop-item:hover{background:var(--green-50);}
.am-burger{display:none;background:none;border:1px solid var(--border-default);border-radius:var(--radius-sm);width:42px;height:42px;align-items:center;justify-content:center;cursor:pointer;color:var(--green-700);}
@media(max-width:960px){.am-nav-desktop{display:none !important;}.am-burger{display:inline-flex;}}
`;
function ensureNavCSS() {
  if (typeof document !== 'undefined' && !document.getElementById('am-nav-css')) {
    const s = document.createElement('style');
    s.id = 'am-nav-css';
    s.textContent = NAV_CSS;
    document.head.appendChild(s);
  }
}
const DEFAULT_ITEMS = [{
  label: 'Beranda',
  href: '#',
  active: true
}, {
  label: 'Berita',
  href: '#'
}, {
  label: 'Prestasi',
  href: '#'
}, {
  label: 'Galeri',
  href: '#'
}, {
  label: 'Sekolah',
  href: '#',
  children: [{
    label: 'SDIT AL MANAR',
    desc: 'Sekolah Dasar Islam Terpadu',
    href: '#'
  }, {
    label: 'TKIT AL MANAR',
    desc: 'TK Islam Terpadu',
    href: '#'
  }]
}, {
  label: 'Portal Akademik',
  href: '#'
}, {
  label: 'Kontak',
  href: '#'
}];

/** Primary site navigation with SEKOLAH dropdown, utility top strip, and mobile menu. */
function NavBar({
  items = DEFAULT_ITEMS,
  topbar = true,
  ctaLabel = 'Daftar Sekarang',
  onCta,
  onNavigate,
  style,
  ...rest
}) {
  ensureNavCSS();
  const [open, setOpen] = useState(false);
  const nav = (item, e) => {
    if (onNavigate) {
      e.preventDefault();
      onNavigate(item, e);
      setOpen(false);
    }
  };
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 50,
      ...style
    }
  }, rest), topbar && /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--green-800)',
      color: 'var(--gold-200)',
      fontSize: 'var(--text-xs)',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '7px var(--gutter)',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "am-arabic",
    style: {
      fontSize: '14px',
      color: 'var(--gold-300)'
    }
  }, "\u0627\u0644\u0633\u0644\u0627\u0645 \u0639\u0644\u064A\u0643\u0645"), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .85
    }
  }, "Selamat datang di Yayasan AL MANAR Kota Bekasi")), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 18,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .85
    }
  }, "(021) 8273-xxxx"), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .85
    }
  }, "ppdb@almanar.sch.id")))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'rgba(251,248,241,0.92)',
      backdropFilter: 'blur(8px)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 var(--gutter)',
      height: 'var(--navbar-h)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => nav({
      key: 'home'
    }, e),
    style: {
      display: 'flex',
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    variant: "full",
    tone: "dark",
    size: 42,
    subtitle: "Yayasan \xB7 Kota Bekasi"
  })), /*#__PURE__*/React.createElement("nav", {
    className: "am-nav-desktop",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 26
    }
  }, items.map(it => it.children ? /*#__PURE__*/React.createElement("span", {
    key: it.label,
    className: "am-nav-dropwrap",
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "am-nav-link",
    "data-active": it.active,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, it.label, /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "am-nav-drop"
  }, it.children.map(c => /*#__PURE__*/React.createElement("a", {
    key: c.label,
    href: c.href,
    onClick: e => nav(c, e),
    className: "am-drop-item"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--gold-400)',
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      fontSize: 'var(--text-sm)',
      color: 'var(--green-800)'
    }
  }, c.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--ink-500)'
    }
  }, c.desc)))))) : /*#__PURE__*/React.createElement("a", {
    key: it.label,
    href: it.href,
    onClick: e => nav(it, e),
    className: "am-nav-link",
    "data-active": it.active
  }, it.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "am-nav-desktop"
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "sm",
    onClick: onCta
  }, ctaLabel)), /*#__PURE__*/React.createElement("button", {
    className: "am-burger",
    "aria-label": "Menu",
    onClick: () => setOpen(v => !v)
  }, /*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "22",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "3",
    y1: "6",
    x2: "21",
    y2: "6"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "3",
    y1: "12",
    x2: "21",
    y2: "12"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "3",
    y1: "18",
    x2: "21",
    y2: "18"
  }))))), open && /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      background: 'var(--cream-50)',
      padding: '12px var(--gutter) 18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, items.map(it => /*#__PURE__*/React.createElement("a", {
    key: it.label,
    href: it.href,
    onClick: e => nav(it, e),
    className: "am-nav-link",
    "data-active": it.active,
    style: {
      padding: '12px 4px',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, it.label)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    block: true,
    onClick: onCta
  }, ctaLabel))))));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/app.jsx
try { (() => {
/* AL MANAR website — app shell + shared layout helpers.
 * DS components are available as globals (flattened from the bundle in index.html).
 */
const {
  useState
} = React;

/* ── Layout primitives ─────────────────────────────────────────── */
function Container({
  children,
  wide,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: wide ? 'var(--container-wide)' : 'var(--container-max)',
      margin: '0 auto',
      padding: '0 var(--gutter)',
      ...style
    }
  }, children);
}
function Section({
  children,
  bg = 'page',
  pad = 'var(--section-y)',
  style
}) {
  const background = bg === 'cream' ? 'var(--cream-100)' : bg === 'green' ? 'var(--green-800)' : bg === 'white' ? '#fff' : 'var(--cream-50)';
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background,
      paddingTop: pad,
      paddingBottom: pad,
      ...style
    }
  }, children);
}

/* Simple intersection-reveal wrapper (fade + rise, respects reduced motion) */
function Reveal({
  children,
  delay = 0,
  style
}) {
  const ref = React.useRef(null);
  const [vis, setVis] = useState(false);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setVis(true);
      return;
    }
    const io = new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting) {
        setVis(true);
        io.disconnect();
      }
    }), {
      threshold: 0.12
    });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      opacity: vis ? 1 : 0,
      transform: vis ? 'none' : 'translateY(16px)',
      transition: `opacity .6s var(--ease-out) ${delay}ms, transform .6s var(--ease-out) ${delay}ms`,
      ...style
    }
  }, children);
}
Object.assign(window, {
  Container,
  Section,
  Reveal
});

/* ── App root ──────────────────────────────────────────────────── */
const NAV_ITEMS = [{
  key: 'home',
  label: 'Beranda',
  href: '#'
}, {
  key: 'news',
  label: 'Berita',
  href: '#'
}, {
  key: 'achievements',
  label: 'Prestasi',
  href: '#'
}, {
  key: 'gallery',
  label: 'Galeri',
  href: '#'
}, {
  key: 'sekolah',
  label: 'Sekolah',
  href: '#',
  children: [{
    key: 'sdit',
    label: 'SDIT AL MANAR',
    desc: 'Sekolah Dasar Islam Terpadu',
    href: '#'
  }, {
    key: 'tkit',
    label: 'TKIT AL MANAR',
    desc: 'TK Islam Terpadu',
    href: '#'
  }]
}, {
  key: 'portal',
  label: 'Portal Akademik',
  href: '#'
}, {
  key: 'kontak',
  label: 'Kontak',
  href: '#'
}];
function App() {
  const [page, setPage] = useState('home');
  const [school, setSchool] = useState('SDIT');
  const go = (key, opts = {}) => {
    if (key === 'sdit') {
      setSchool('SDIT');
      setPage('profile');
    } else if (key === 'tkit') {
      setSchool('TKIT');
      setPage('profile');
    } else if (key === 'achievements') setPage('news');else if (key === 'kontak') setPage('home');else setPage(key);
    if (opts.school) setSchool(opts.school);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };
  const items = NAV_ITEMS.map(it => ({
    ...it,
    active: it.key === page || it.key === 'sekolah' && page === 'profile'
  }));
  const Page = page === 'profile' ? /*#__PURE__*/React.createElement(SchoolProfile, {
    school: school,
    go: go,
    setSchool: setSchool
  }) : page === 'news' ? /*#__PURE__*/React.createElement(NewsPage, {
    go: go
  }) : page === 'gallery' ? /*#__PURE__*/React.createElement(GalleryPage, {
    go: go
  }) : page === 'registration' ? /*#__PURE__*/React.createElement(Registration, {
    go: go,
    defaultSchool: school
  }) : page === 'portal' ? /*#__PURE__*/React.createElement(AcademicPortal, {
    go: go
  }) : /*#__PURE__*/React.createElement(Home, {
    go: go
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--cream-50)'
    }
  }, /*#__PURE__*/React.createElement(NavBar, {
    items: items,
    ctaLabel: "Daftar Sekarang",
    onCta: () => go('registration'),
    onNavigate: it => go(it.key)
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1
    }
  }, Page), /*#__PURE__*/React.createElement(Footer, null));
}
Object.assign(window, {
  App
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/home.jsx
try { (() => {
/* AL MANAR — Homepage */
function Home({
  go
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(HomeHero, {
    go: go
  }), /*#__PURE__*/React.createElement(SchoolsSplit, {
    go: go
  }), /*#__PURE__*/React.createElement(AchievementsBand, null), /*#__PURE__*/React.createElement(NewsPreview, {
    go: go
  }), /*#__PURE__*/React.createElement(ActivitiesStrip, null), /*#__PURE__*/React.createElement(GalleryTeaser, {
    go: go
  }), /*#__PURE__*/React.createElement(PpdbCta, {
    go: go
  }));
}

/* ── Hero ──────────────────────────────────────────────────────── */
function HomeHero({
  go
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--cream-50)',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(Container, {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.05fr 0.95fr',
      gap: 56,
      alignItems: 'center',
      paddingTop: 'clamp(2.5rem,4vw,4.5rem)',
      paddingBottom: 'clamp(2.5rem,4vw,4.5rem)'
    },
    wide: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      maxWidth: 560
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      fontWeight: 700,
      letterSpacing: '.14em',
      textTransform: 'uppercase',
      color: 'var(--gold-600)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 2,
      background: 'var(--gold-400)',
      borderRadius: 2
    }
  }), "Yayasan AL MANAR \xB7 Kota Bekasi"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 'var(--text-5xl)',
      lineHeight: 1.06,
      letterSpacing: '-0.025em',
      color: 'var(--ink-900)',
      margin: 0
    }
  }, "Menumbuhkan generasi ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--green-600)'
    }
  }, "Qur'ani"), " yang berakhlak & berprestasi"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-md)',
      lineHeight: 1.7,
      color: 'var(--ink-500)',
      margin: 0
    }
  }, "Pendidikan Islam terpadu dari TK hingga sekolah dasar \u2014 memadukan kurikulum nasional, pembinaan akhlak, dan tahfizh Al-Qur'an di lingkungan yang hangat dan aman."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap',
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => go('registration')
  }, "Daftar Sekarang"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "lg",
    onClick: () => go('sdit')
  }, "Profil Sekolah")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 36,
      marginTop: 14,
      paddingTop: 22,
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "A",
    label: "Akreditasi",
    sublabel: "SDIT & TKIT",
    tone: "gold"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "1.200+",
    label: "Alumni",
    sublabel: "Sejak 2009"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "40+",
    label: "Tenaga Pendidik",
    sublabel: "Tersertifikasi"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-2xl)',
      overflow: 'hidden',
      border: '1px solid var(--border-default)',
      boxShadow: 'var(--shadow-lg)'
    }
  }, /*#__PURE__*/React.createElement(MediaPlaceholder, {
    height: 420,
    label: "Foto suasana sekolah",
    tone: "green"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: -18,
      bottom: 28,
      background: '#fff',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-md)',
      border: '1px solid var(--border-default)',
      padding: '14px 18px',
      display: 'flex',
      alignItems: 'center',
      gap: 13
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "mark",
    size: 42
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-arabic)',
      direction: 'rtl',
      fontSize: 22,
      color: 'var(--green-700)',
      lineHeight: 1
    }
  }, "\u0627\u0644\u0645\u0646\u0627\u0631"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      color: 'var(--ink-500)',
      marginTop: 3
    }
  }, "Cahaya Ilmu, Akhlak Mulia"))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: -14,
      top: 24
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    variant: "solid",
    size: "md"
  }, "PPDB 2026 Dibuka")))));
}

/* ── Schools split ─────────────────────────────────────────────── */
function SchoolsSplit({
  go
}) {
  return /*#__PURE__*/React.createElement(Section, {
    bg: "page"
  }, /*#__PURE__*/React.createElement(Container, null, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: "Unit Pendidikan",
    title: "Satu yayasan, dua jenjang terpadu",
    lead: "Pendidikan Islam yang berkesinambungan \u2014 dari usia dini hingga sekolah dasar.",
    style: {
      marginBottom: 36
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 28
    },
    className: "am-grid-2"
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement(SchoolCard, {
    level: "SDIT",
    name: "SDIT AL MANAR",
    tagline: "Sekolah Dasar Islam Terpadu",
    description: "Kurikulum nasional terintegrasi nilai Islam, program tahfizh, dan pembinaan karakter yang kuat.",
    ageRange: "7\u201312 tahun",
    accreditation: "A",
    points: ["Target hafalan hingga 3 juz", "Pembelajaran bilingual & literasi digital", "Ekstrakurikuler lengkap & pramuka SIT"],
    media: /*#__PURE__*/React.createElement(MediaPlaceholder, {
      height: 190,
      label: "Foto SDIT",
      tone: "green"
    }),
    onClick: () => go('sdit'),
    style: {
      cursor: 'pointer'
    }
  })), /*#__PURE__*/React.createElement(Reveal, {
    delay: 80
  }, /*#__PURE__*/React.createElement(SchoolCard, {
    level: "TKIT",
    name: "TKIT AL MANAR",
    tagline: "TK Islam Terpadu",
    description: "Belajar sambil bermain dengan pembiasaan ibadah, adab, dan stimulasi tumbuh kembang yang menyenangkan.",
    ageRange: "4\u20136 tahun",
    accreditation: "A",
    points: ["Sentra bermain edukatif", "Pembiasaan sholat, doa & hadits", "Rasio guru–murid ideal"],
    media: /*#__PURE__*/React.createElement(MediaPlaceholder, {
      height: 190,
      label: "Foto TKIT",
      tone: "gold"
    }),
    onClick: () => go('tkit'),
    style: {
      cursor: 'pointer'
    }
  })))));
}

/* ── Achievements band (green) ─────────────────────────────────── */
function AchievementsBand() {
  const stats = [{
    value: '32',
    label: 'Prestasi diraih',
    sub: '2 tahun terakhir'
  }, {
    value: '95%',
    label: 'Lulusan diterima',
    sub: 'SMP/MTs favorit'
  }, {
    value: '3 Juz',
    label: 'Target tahfizh',
    sub: 'Jenjang SDIT'
  }, {
    value: '18',
    label: 'Ekstrakurikuler',
    sub: 'Akademik & non-akademik'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--green-800)',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: 'var(--pattern-girih)',
      opacity: .5
    },
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement(Container, {
    style: {
      position: 'relative',
      paddingTop: 'var(--section-y)',
      paddingBottom: 'var(--section-y)'
    }
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement(SectionHeader, {
    tone: "onbrand",
    align: "center",
    eyebrow: "Prestasi & Capaian",
    title: "Hasil yang membanggakan, akhlak yang utama",
    style: {
      justifyContent: 'center',
      marginBottom: 40
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 24
    },
    className: "am-grid-4"
  }, stats.map((s, i) => /*#__PURE__*/React.createElement(Reveal, {
    key: s.label,
    delay: i * 70
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'rgba(251,248,241,0.06)',
      border: '1px solid rgba(217,171,61,0.25)',
      borderRadius: 'var(--radius-lg)',
      padding: '24px 22px'
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: s.value,
    label: s.label,
    sublabel: s.sub,
    tone: "onbrand"
  })))))));
}
Object.assign(window, {
  Home
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/home.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.PatternBand = __ds_scope.PatternBand;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.MediaPlaceholder = __ds_scope.MediaPlaceholder;

__ds_ns.NewsCard = __ds_scope.NewsCard;

__ds_ns.SchoolCard = __ds_scope.SchoolCard;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.FileUpload = __ds_scope.FileUpload;

__ds_ns.FormField = __ds_scope.FormField;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.NavBar = __ds_scope.NavBar;

})();
